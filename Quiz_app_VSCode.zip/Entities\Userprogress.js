{
  "name": "UserProgress",
  "type": "object",
  "properties": {
    "subject": {
      "type": "string",
      "enum": [
        "dsa_c",
        "oops_cpp",
        "software_engineering",
        "c_language",
        "digital_electronics",
        "java",
        "python"
      ]
    },
    "mastery_level": {
      "type": "number",
      "minimum": 0,
      "maximum": 100,
      "description": "Overall mastery percentage for this subject"
    },
    "quizzes_taken": {
      "type": "number",
      "default": 0
    },
    "average_score": {
      "type": "number",
      "minimum": 0,
      "maximum": 100
    },
    "last_quiz_date": {
      "type": "string",
      "format": "date"
    },
    "recommended_difficulty": {
      "type": "string",
      "enum": [
        "easy",
        "medium",
        "hard"
      ],
      "default": "easy"
    },
    "priority_tasks": {
      "type": "array",
      "items": {
        "type": "string"
      }
    }
  },
  "required": [
    "subject",
    "mastery_level"
  ],
  "rls": {
    "read": {
      "$or": [
        {
          "created_by": "{{user.email}}"
        },
        {
          "user_condition": {
            "role": "admin"
          }
        }
      ]
    },
    "write": {
      "$or": [
        {
          "created_by": "{{user.email}}"
        },
        {
          "user_condition": {
            "role": "admin"
          }
        }
      ]
    }
  }
}