import React, { useState, useEffect } from 'react';
import { User } from '@/entities/User';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { User as UserIcon, LogIn, Edit, Save, Image as ImageIcon } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

export default function AccountPage() {
  const [user, setUser] = useState(null);
  const [isGuest, setIsGuest] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [fullName, setFullName] = useState('');
  const [profilePicUrl, setProfilePicUrl] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        setFullName(currentUser.full_name || '');
        setProfilePicUrl(currentUser.profile_pic_url || '');
        setIsGuest(false);
      } catch (error) {
        setIsGuest(true);
      }
      setIsLoading(false);
    };
    fetchUser();
  }, []);
  
  const handleLogin = async () => {
    await User.login();
  };

  const handleSave = async () => {
    try {
      await User.updateMyUserData({
        full_name: fullName,
        profile_pic_url: profilePicUrl,
      });
      setUser(prev => ({ ...prev, full_name: fullName, profile_pic_url: profilePicUrl }));
      setIsEditing(false);
      toast({
        title: "Profile Updated",
        description: "Your changes have been saved successfully.",
      });
    } catch (error) {
      console.error("Error updating profile:", error);
      toast({
        title: "Update Failed",
        description: "Could not save your changes. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-950">
        <div className="w-full max-w-md p-8">
          <Card className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800 animate-pulse">
            <CardHeader>
              <div className="h-8 bg-gray-300 dark:bg-gray-700 rounded w-3/4"></div>
              <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-1/2 mt-2"></div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="h-10 bg-gray-300 dark:bg-gray-700 rounded"></div>
              <div className="h-10 bg-gray-300 dark:bg-gray-700 rounded"></div>
              <div className="h-12 bg-gray-300 dark:bg-gray-700 rounded"></div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (isGuest) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-950 p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <Card className="w-full max-w-md bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800 text-center">
            <CardHeader>
              <UserIcon className="mx-auto h-12 w-12 text-gray-400" />
              <CardTitle className="mt-4 text-2xl font-bold text-gray-900 dark:text-white">You are a Guest</CardTitle>
              <CardDescription className="mt-2 text-gray-500 dark:text-gray-400">
                Create an account to save your progress, track your performance, and unlock all features.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={handleLogin}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
              >
                <LogIn className="w-4 h-4 mr-2" />
                Sign Up or Log In
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-950 p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
            <CardHeader className="flex flex-col items-center text-center">
              {user.profile_pic_url ? (
                <img src={user.profile_pic_url} alt="Profile" className="w-24 h-24 rounded-full object-cover border-4 border-purple-500" />
              ) : (
                <div className="w-24 h-24 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center border-4 border-purple-500">
                  <UserIcon className="w-12 h-12 text-gray-500" />
                </div>
              )}
              <CardTitle className="mt-4 text-2xl font-bold text-gray-900 dark:text-white">
                {user.full_name || 'User Profile'}
              </CardTitle>
              <CardDescription className="text-gray-500 dark:text-gray-400">{user.email}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Full Name</label>
                <Input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  disabled={!isEditing}
                  className="bg-gray-50 dark:bg-gray-800 border-gray-300 dark:border-gray-700"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Profile Picture URL</label>
                <Input
                  type="text"
                  value={profilePicUrl}
                  onChange={(e) => setProfilePicUrl(e.target.value)}
                  disabled={!isEditing}
                  className="bg-gray-50 dark:bg-gray-800 border-gray-300 dark:border-gray-700"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">User ID</label>
                <Input
                  type="text"
                  value={user.id}
                  disabled
                  className="bg-gray-200 dark:bg-gray-700 border-gray-300 dark:border-gray-700 cursor-not-allowed"
                />
              </div>

              {isEditing ? (
                <div className="flex gap-4">
                  <Button onClick={handleSave} className="flex-1 bg-green-600 hover:bg-green-700">
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </Button>
                  <Button variant="outline" onClick={() => setIsEditing(false)} className="flex-1">
                    Cancel
                  </Button>
                </div>
              ) : (
                <Button onClick={() => setIsEditing(true)} className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Profile
                </Button>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}