import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { User } from '@/entities/User';
import { QuizResult, UserProgress, ChatMessage } from '@/entities/all';

export default function DebugPanel() {
  const [user, setUser] = useState(null);
  const [stats, setStats] = useState({
    quizResults: 0,
    chatMessages: 0,
    userProgress: 0
  });

  const refreshStats = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      const quizResults = await QuizResult.filter({});
      const chatMessages = await ChatMessage.filter({});
      const userProgress = await UserProgress.filter({});
      
      setStats({
        quizResults: quizResults.length,
        chatMessages: chatMessages.length,
        userProgress: userProgress.length
      });
    } catch (error) {
      setUser(null);
      // Still get stats even if user is not logged in
      const quizResults = await QuizResult.filter({});
      const chatMessages = await ChatMessage.filter({});
      const userProgress = await UserProgress.filter({});
      
      setStats({
        quizResults: quizResults.length,
        chatMessages: chatMessages.length,
        userProgress: userProgress.length
      });
    }
  };

  useEffect(() => {
    refreshStats();
  }, []);

  const enableDemoMode = async () => {
    await User.enableDemoMode();
    refreshStats();
  };

  const disableDemoMode = () => {
    User.disableDemoMode();
    refreshStats();
  };

  const clearAllData = () => {
    localStorage.removeItem('mock_quizresult');
    localStorage.removeItem('mock_chatmessage');
    localStorage.removeItem('mock_userprogress');
    refreshStats();
  };

  const addSampleData = async () => {
    // Add sample quiz result
    await QuizResult.create({
      subject: 'dsa_c',
      difficulty: 'medium',
      score: 85,
      total_questions: 10,
      correct_answers: 8,
      time_taken: 300,
      questions_data: [],
      weak_topics: ['Binary Trees', 'Graph Algorithms'],
      ai_feedback: 'Good performance! Focus on graph algorithms for improvement.'
    });

    // Add sample chat message
    await ChatMessage.create({
      message: 'Hello, can you help me understand binary search?',
      role: 'user',
      subject_context: 'dsa_c'
    });

    await ChatMessage.create({
      message: 'Of course! Binary search is an efficient algorithm for finding a target value in a sorted array...',
      role: 'assistant',
      subject_context: 'dsa_c'
    });

    // Add sample user progress
    await UserProgress.create({
      subject: 'dsa_c',
      mastery_level: 75,
      quizzes_taken: 3,
      average_score: 78,
      last_quiz_date: new Date().toISOString().split('T')[0],
      recommended_difficulty: 'medium',
      priority_tasks: ['Practice graph algorithms', 'Review tree traversal']
    });

    refreshStats();
  };

  return (
    <Card className="bg-gray-900 border-gray-700 text-white">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          🔧 Debug Panel - Data Persistence Status
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="font-semibold mb-2">Current User:</h3>
          {user ? (
            <div className="bg-green-900/30 p-3 rounded border border-green-600">
              <p><strong>Name:</strong> {user.full_name}</p>
              <p><strong>Email:</strong> {user.email}</p>
              <p><strong>Role:</strong> {user.role}</p>
            </div>
          ) : (
            <div className="bg-red-900/30 p-3 rounded border border-red-600">
              <p>No user logged in (Guest mode)</p>
            </div>
          )}
        </div>

        <div>
          <h3 className="font-semibold mb-2">Stored Data:</h3>
          <div className="grid grid-cols-3 gap-2 text-sm">
            <div className="bg-blue-900/30 p-2 rounded text-center">
              <div className="font-bold text-blue-300">{stats.quizResults}</div>
              <div>Quiz Results</div>
            </div>
            <div className="bg-purple-900/30 p-2 rounded text-center">
              <div className="font-bold text-purple-300">{stats.chatMessages}</div>
              <div>Chat Messages</div>
            </div>
            <div className="bg-green-900/30 p-2 rounded text-center">
              <div className="font-bold text-green-300">{stats.userProgress}</div>
              <div>User Progress</div>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="font-semibold">Actions:</h3>
          <div className="flex flex-wrap gap-2">
            {!user ? (
              <Button onClick={enableDemoMode} className="bg-green-600 hover:bg-green-700">
                Enable Demo User
              </Button>
            ) : (
              <Button onClick={disableDemoMode} variant="outline" className="border-gray-600">
                Logout (Guest Mode)
              </Button>
            )}
            <Button onClick={addSampleData} className="bg-blue-600 hover:bg-blue-700">
              Add Sample Data
            </Button>
            <Button onClick={clearAllData} variant="destructive">
              Clear All Data
            </Button>
            <Button onClick={refreshStats} variant="outline" className="border-gray-600">
              Refresh Stats
            </Button>
          </div>
        </div>

        <div className="text-xs text-gray-400 bg-gray-800 p-3 rounded">
          <p><strong>How it works:</strong></p>
          <ul className="list-disc list-inside space-y-1 mt-1">
            <li>Data is stored in browser localStorage for persistence</li>
            <li>Enable "Demo User" to simulate logged-in state</li>
            <li>Quiz results and chat history will be saved and displayed</li>
            <li>Guest mode still saves data but with limited features</li>
            <li>Clear data to reset everything and test from scratch</li>
          </ul>
          
          <div className="mt-3 pt-2 border-t border-gray-700">
            <p><strong>AI Status:</strong></p>
            <div className="mt-1">
              {import.meta.env.VITE_GEMINI_API_KEY ? (
                <span className="text-green-400">🤖 Real Google Gemini AI Configured</span>
              ) : (
                <span className="text-yellow-400">📚 Using Comprehensive Question Bank (500+ questions from legitimate sources)</span>
              )}
            </div>
            {!import.meta.env.VITE_GEMINI_API_KEY && (
              <p className="text-xs mt-1 opacity-75">
                To enable real AI: Add VITE_GEMINI_API_KEY to .env file
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
