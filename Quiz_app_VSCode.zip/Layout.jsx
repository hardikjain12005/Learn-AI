import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from '@/entities/User';
import { Button } from "@/components/ui/button";
import { 
  Brain, 
  BookOpen, 
  MessageCircle, 
  BarChart3, 
  User as UserIcon,
  History,
  LogOut
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import ThemeSwitcher from './Components/ThemeSwitcher.jsx';

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("dashboard"),
    icon: BarChart3,
  },
  {
    title: "Quiz",
    url: createPageUrl("quiz"),
    icon: BookOpen,
  },
  {
    title: "History",
    url: createPageUrl("history"),
    icon: History,
  },
  {
    title: "AI Tutor",
    url: createPageUrl("tutor"),
    icon: MessageCircle,
  },
  {
    title: "Account",
    url: createPageUrl("account"),
    icon: UserIcon,
  }
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [theme, setTheme] = useState('dark');
  const [user, setUser] = useState(null);
  const [isGuest, setIsGuest] = useState(false);

  useEffect(() => {
    const storedTheme = localStorage.getItem('theme') || 'dark';
    setTheme(storedTheme);
    document.documentElement.classList.toggle('dark', storedTheme === 'dark');
    
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        setIsGuest(false);
      } catch (error) {
        setIsGuest(true);
      }
    };
    fetchUser();
  }, [location.pathname]);

  const handleLogout = async () => {
    await User.logout();
    window.location.reload();
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      theme === 'dark' 
        ? 'bg-gray-950 text-white' 
        : 'bg-gray-50 text-gray-900'
    }`}>
      <SidebarProvider>
        <div className="min-h-screen flex w-full">
          <Sidebar className={`border-r transition-colors duration-300 ${
            theme === 'dark'
              ? 'border-gray-800 bg-gray-900 text-white'
              : 'border-gray-200 bg-white text-gray-900'
          }`}>
            <SidebarHeader className={`border-b p-4 transition-colors duration-300 ${
              theme === 'dark' ? 'border-gray-800' : 'border-gray-200'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                    <Brain className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
                      LearnAI
                    </h2>
                  </div>
                </div>
                <ThemeSwitcher theme={theme} setTheme={setTheme} />
              </div>
            </SidebarHeader>
            
            <SidebarContent className="p-2">
              <SidebarGroup>
                <SidebarGroupLabel className={`text-xs font-medium uppercase tracking-wider px-3 py-3 transition-colors duration-300 ${
                  theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                }`}>
                  Navigation
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {navigationItems.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton 
                          asChild 
                          className={`transition-all duration-200 rounded-xl mb-1 ${
                            location.pathname === item.url 
                              ? theme === 'dark'
                                ? 'bg-gray-800 text-purple-400' 
                                : 'bg-gray-200 text-purple-600'
                              : theme === 'dark'
                                ? 'text-gray-300 hover:bg-gray-800 hover:text-purple-400'
                                : 'text-gray-600 hover:bg-gray-100 hover:text-purple-600'
                          }`}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-3 py-3">
                            <item.icon className="w-5 h-5" />
                            <span className="font-medium">{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>

            <SidebarFooter className={`border-t p-4 transition-colors duration-300 ${
              theme === 'dark' ? 'border-gray-800' : 'border-gray-200'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center">
                    <UserIcon className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`font-medium text-sm truncate transition-colors duration-300 ${
                      theme === 'dark' ? 'text-gray-100' : 'text-gray-800'
                    }`}>
                      {isGuest ? 'Guest User' : (user?.full_name || 'Student')}
                    </p>
                    <p className={`text-xs truncate transition-colors duration-300 ${
                      theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                    }`}>
                      {isGuest ? 'Sign up to save progress' : (user?.email || 'Keep learning!')}
                    </p>
                  </div>
                </div>
                {!isGuest && (
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={handleLogout} 
                    className={`transition-colors duration-300 ${
                      theme === 'dark' 
                        ? 'text-gray-400 hover:bg-gray-800' 
                        : 'text-gray-500 hover:bg-gray-200'
                    }`}
                  >
                    <LogOut className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </SidebarFooter>
          </Sidebar>

          <main className={`flex-1 flex flex-col transition-colors duration-300 ${
            theme === 'dark' 
              ? 'bg-gray-950 text-white' 
              : 'bg-gray-50 text-gray-900'
          }`}>
            <header className={`border-b px-6 py-4 md:hidden transition-colors duration-300 ${
              theme === 'dark' 
                ? 'bg-gray-900 border-gray-800' 
                : 'bg-white border-gray-200'
            }`}>
              <div className="flex items-center justify-between">
                <SidebarTrigger className={`p-2 rounded-lg transition-colors duration-200 ${
                  theme === 'dark' 
                    ? 'hover:bg-gray-800 text-gray-300' 
                    : 'hover:bg-gray-200 text-gray-600'
                }`} />
                <h1 className={`text-xl font-semibold transition-colors duration-300 ${
                  theme === 'dark' ? 'text-white' : 'text-gray-900'
                }`}>LearnAI</h1>
                <ThemeSwitcher theme={theme} setTheme={setTheme} />
              </div>
            </header>

            <div className="flex-1 overflow-auto">
              {children}
            </div>
          </main>
        </div>
      </SidebarProvider>
    </div>
  );
}