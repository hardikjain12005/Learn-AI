
import React, { useState, useEffect, useCallback } from "react";
import { QuizResult, UserProgress } from "@/entities/all";
import { User } from "@/entities/User";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  BookOpen, 
  Brain, 
  Trophy, 
  Target, 
  TrendingUp,
  Clock,
  Star,
  Zap,
  ChevronRight
} from "lucide-react";
import { motion } from "framer-motion";
import DebugPanel from '../Components/DebugPanel.jsx';
import AITestPanel from '../Components/AITestPanel.jsx';

const subjects = {
  dsa_c: { name: "DSA (C)", color: "from-blue-500 to-cyan-500", icon: "🔢" },
  oops_cpp: { name: "OOPS (C++)", color: "from-purple-500 to-pink-500", icon: "🎯" },
  software_engineering: { name: "Software Engineering", color: "from-green-500 to-emerald-500", icon: "⚙️" },
  c_language: { name: "C Language", color: "from-orange-500 to-red-500", icon: "💻" },
  digital_electronics: { name: "Digital Electronics", color: "from-indigo-500 to-purple-500", icon: "⚡" },
  java: { name: "JAVA", color: "from-red-500 to-pink-500", icon: "☕" },
  python: { name: "Python", color: "from-yellow-500 to-orange-500", icon: "🐍" }
};

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [quizResults, setQuizResults] = useState([]);
  const [userProgress, setUserProgress] = useState([]);
  const [prioritizedTasks, setPrioritizedTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const generatePrioritizedTasks = useCallback(async (results) => {
    try {
      const performanceData = results.map(r => ({
        subject: r.subject,
        difficulty: r.difficulty,
        score: r.score,
        weak_topics: r.weak_topics || [],
      }));

      const prompt = `Based on the user's last ${performanceData.length} quiz results, generate a prioritized, actionable task list of 3-5 items to help them improve.

      PERFORMANCE DATA: ${JSON.stringify(performanceData)}

      Analyze their weaknesses and suggest specific, concrete tasks.

      Return a JSON object with this exact structure:
      {
        "tasks": [
          {
            "task": "A specific, actionable task title.",
            "reason": "A brief explanation of why this task is important based on their performance.",
            "subject": "The relevant subject code (e.g., 'dsa_c', 'python').",
            "recommendedDifficulty": "The recommended difficulty for the next quiz on this topic ('easy', 'medium', or 'hard')."
          }
        ]
      }`;

      const { InvokeLLM } = await import("@/integrations/Core");
      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            tasks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  task: { type: "string" },
                  reason: { type: "string" },
                  subject: { type: "string", enum: Object.keys(subjects) },
                  recommendedDifficulty: { type: "string", enum: ["easy", "medium", "hard"] }
                },
                required: ["task", "reason", "subject", "recommendedDifficulty"]
              }
            }
          },
          required: ["tasks"]
        }
      });

      setPrioritizedTasks(response.tasks || []);
    } catch (error) {
      console.error("Error generating tasks:", error);
    }
  }, []);

  const loadDashboardData = useCallback(async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      const results = await QuizResult.filter({ created_by: currentUser.email }, '-created_date', 20);
      setQuizResults(results);

      const progress = await UserProgress.filter({ created_by: currentUser.email });
      setUserProgress(progress);

      // Generate prioritized tasks if we have quiz history, using last 3 results
      if (results.length > 0) {
        generatePrioritizedTasks(results.slice(0, 3));
      }
    } catch (error) {
      console.error("Error loading dashboard:", error);
    }
    setIsLoading(false);
  }, [generatePrioritizedTasks]);

  useEffect(() => {
    loadDashboardData();
  }, [loadDashboardData]);

  const getOverallStats = () => {
    if (quizResults.length === 0) return { avgScore: 0, totalQuizzes: 0, strongSubject: null };
    
    const avgScore = quizResults.reduce((sum, r) => sum + r.score, 0) / quizResults.length;
    const subjectScores = {};
    
    quizResults.forEach(r => {
      if (!subjectScores[r.subject]) subjectScores[r.subject] = [];
      subjectScores[r.subject].push(r.score);
    });

    let strongSubject = null;
    let highestAvg = 0;
    Object.entries(subjectScores).forEach(([subject, scores]) => {
      const avg = scores.reduce((sum, score) => sum + score, 0) / scores.length;
      if (avg > highestAvg) {
        highestAvg = avg;
        strongSubject = subject;
      }
    });

    return { avgScore, totalQuizzes: quizResults.length, strongSubject };
  };

  const stats = getOverallStats();

  if (isLoading) {
    return (
      <div className="p-8 space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-800 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-800 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Welcome Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 rounded-2xl p-6 border border-purple-500/20">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
              Welcome back! 🚀
            </h1>
            <p className="text-gray-300 text-lg">
              Ready to level up your skills today?
            </p>
            <div className="mt-4 flex flex-wrap gap-4">
              <Link to={createPageUrl("quiz")}>
                <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Start Quiz
                </Button>
              </Link>
              <Link to={createPageUrl("tutor")}>
                <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-800">
                  <Brain className="w-4 h-4 mr-2" />
                  AI Tutor
                </Button>
              </Link>
            </div>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        >
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Average Score</p>
                  <p className="text-2xl font-bold text-white">{stats.avgScore.toFixed(1)}%</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Quizzes Taken</p>
                  <p className="text-2xl font-bold text-white">{stats.totalQuizzes}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
                  <Target className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Strongest Subject</p>
                  <p className="text-lg font-bold text-white">
                    {stats.strongSubject ? subjects[stats.strongSubject]?.name : "Keep practicing!"}
                  </p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <Star className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Subject Progress */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-purple-400" />
                    Subject Mastery
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {Object.entries(subjects).map(([key, subject]) => {
                      const progress = userProgress.find(p => p.subject === key);
                      const mastery = progress?.mastery_level || 0;
                      
                      return (
                        <div key={key} className="p-4 bg-gray-800 rounded-xl">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              <span className="text-lg">{subject.icon}</span>
                              <span className="text-white font-medium text-sm">{subject.name}</span>
                            </div>
                            <Badge className="bg-gray-700 text-gray-300">
                              {mastery.toFixed(0)}%
                            </Badge>
                          </div>
                          <Progress value={mastery} className="h-2" />
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Recent Quiz Results */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Clock className="w-5 h-5 text-blue-400" />
                    Recent Quiz Results
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {quizResults.length === 0 ? (
                    <div className="text-center py-8">
                      <BookOpen className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                      <p className="text-gray-400">No quizzes taken yet</p>
                      <Link to={createPageUrl("quiz")}>
                        <Button className="mt-4 bg-gradient-to-r from-purple-500 to-pink-500">
                          Take Your First Quiz
                        </Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {quizResults.slice(0, 5).map((result, index) => (
                        <div key={result.id} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                          <div className="flex items-center gap-3">
                            <span className="text-lg">{subjects[result.subject]?.icon}</span>
                            <div>
                              <p className="text-white font-medium">{subjects[result.subject]?.name}</p>
                              <p className="text-gray-400 text-sm">
                                {result.correct_answers}/{result.total_questions} correct
                              </p>
                            </div>
                          </div>
                          <Badge className={`${
                            result.score >= 80 ? 'bg-green-900 text-green-300' :
                            result.score >= 60 ? 'bg-yellow-900 text-yellow-300' :
                            'bg-red-900 text-red-300'
                          }`}>
                            {result.score.toFixed(0)}%
                          </Badge>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Sidebar Content */}
          <div className="space-y-6">
            {/* Enhanced AI Priority Tasks */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-400" />
                    Your Priority Tasks
                  </CardTitle>
                  <p className="text-gray-400 text-sm">AI-generated tasks based on your recent performance</p>
                </CardHeader>
                <CardContent>
                  {prioritizedTasks.length === 0 ? (
                    <div className="text-center py-6">
                      <Brain className="w-8 h-8 text-gray-600 mx-auto mb-3" />
                      <p className="text-gray-400 text-sm">Take a quiz to get AI-powered learning recommendations!</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {prioritizedTasks.map((task, index) => (
                        <div key={index} className="p-4 bg-gray-800 rounded-lg border border-gray-700">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-medium text-white text-sm">{task.task}</h4>
                            {subjects[task.subject] && (
                                <span className="text-xl" title={subjects[task.subject].name}>{subjects[task.subject].icon}</span>
                            )}
                          </div>
                          <p className="text-gray-300 text-xs leading-relaxed mb-3">{task.reason}</p>
                          
                          <div className="flex items-center gap-2">
                            <Badge className={`text-xs ${
                              task.recommendedDifficulty === 'hard' ? 'bg-red-900 text-red-300' :
                              task.recommendedDifficulty === 'medium' ? 'bg-yellow-900 text-yellow-300' :
                              'bg-green-900 text-green-300'
                            }`}>
                              Recommended: {task.recommendedDifficulty}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Quick Actions */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
            >
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Link to={createPageUrl("quiz")} className="block">
                    <Button variant="outline" className="w-full justify-between border-gray-600 text-gray-300 hover:bg-gray-800">
                      Take Quiz
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </Link>
                  <Link to={createPageUrl("tutor")} className="block">
                    <Button variant="outline" className="w-full justify-between border-gray-600 text-gray-300 hover:bg-gray-800">
                      Ask AI Tutor
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>

            {/* Debug Panel */}
            {/* AI Test Panel */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
            >
              <AITestPanel />
            </motion.div>
            
            {/* Debug Panel */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.7 }}
            >
              <DebugPanel />
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
