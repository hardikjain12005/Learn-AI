// Mock User entity with localStorage persistence for development
export class User {
  constructor(data = {}) {
    this.email = data.email || 'guest@example.com';
    this.full_name = data.full_name || 'Guest User';
    this.role = data.role || 'user';
    this.id = data.id || Date.now().toString();
  }

  static async me() {
    // Check if user is logged in via localStorage
    const userData = localStorage.getItem('current_user');
    if (userData) {
      const user = JSON.parse(userData);
      // Update created_by in all mock entities to use the current user
      return new User(user);
    }
    
    // Check if we want to simulate a logged-in demo user
    const demoMode = localStorage.getItem('demo_user_mode');
    if (demoMode === 'true') {
      const demoUser = {
        email: 'demo@example.com',
        full_name: 'Demo Student',
        role: 'user',
        id: 'demo_user_123'
      };
      localStorage.setItem('current_user', JSON.stringify(demoUser));
      return new User(demoUser);
    }
    
    // Simulate guest mode
    throw new Error('Not authenticated');
  }

  static async login(credentials = {}) {
    // Mock login implementation
    const userData = {
      email: credentials.email || 'demo@example.com',
      full_name: credentials.full_name || 'Demo Student',
      role: 'user',
      id: 'demo_user_123'
    };
    
    localStorage.setItem('current_user', JSON.stringify(userData));
    localStorage.setItem('demo_user_mode', 'true');
    return new User(userData);
  }

  static async logout() {
    // Mock logout implementation
    localStorage.removeItem('current_user');
    localStorage.removeItem('demo_user_mode');
    return true;
  }

  static async register(userData) {
    // Mock registration implementation
    const newUser = {
      ...userData,
      role: 'user',
      id: Date.now().toString()
    };
    
    localStorage.setItem('current_user', JSON.stringify(newUser));
    localStorage.setItem('demo_user_mode', 'true');
    return new User(newUser);
  }

  // Helper method to enable demo mode for testing
  static enableDemoMode() {
    localStorage.setItem('demo_user_mode', 'true');
    return this.me();
  }

  // Helper method to disable demo mode (go back to guest)
  static disableDemoMode() {
    localStorage.removeItem('demo_user_mode');
    localStorage.removeItem('current_user');
  }
}
