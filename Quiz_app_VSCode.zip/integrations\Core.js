// AI integration with comprehensive local bank (OpenAI optional)

// Check if Gemini is configured (safely)
function isGeminiConfigured() {
  try {
    return !!import.meta.env.VITE_GEMINI_API_KEY;
  } catch (error) {
    return false;
  }
}

// Gemini integration functions (will be imported dynamically if needed)
async function tryGemini(operation, params) {
  try {
    if (!isGeminiConfigured()) {
      return null;
    }
    
    const geminiModule = await import('./Gemini.js');
    
    if (operation === 'questions') {
      return await geminiModule.generateQuestionsWithGemini(params);
    } else if (operation === 'chat') {
      return await geminiModule.generateChatResponseWithGemini(params);
    }
  } catch (error) {
    console.log('Gemini operation failed, using local fallback:', error.message);
    return null;
  }
}

export async function InvokeLLM({ prompt, response_json_schema, add_context_from_internet = false }) {
  console.log(`AI Integration called - Using ${isGeminiConfigured() ? 'Google Gemini + Local Bank' : 'Local Question Bank'}`);
  
  // Add realistic delay to simulate API processing
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Mock response for task generation
  if (response_json_schema?.properties?.tasks) {
    return {
      tasks: [
        {
          task: "Practice array manipulation problems",
          reason: "Based on your quiz history, you seem to struggle with array-based algorithms",
          subject: "dsa_c",
          recommendedDifficulty: "medium"
        },
        {
          task: "Review object-oriented programming concepts",
          reason: "Your performance on OOP questions could be improved",
          subject: "oops_cpp", 
          recommendedDifficulty: "easy"
        },
        {
          task: "Study software design patterns",
          reason: "This will help you understand better software architecture",
          subject: "software_engineering",
          recommendedDifficulty: "hard"
        }
      ]
    };
  }

  // Quiz question generation with real AI fallback to comprehensive local bank
  if (response_json_schema?.properties?.questions) {
    const requestedCount = extractQuestionCount(prompt) || 10;
    const subject = extractSubjectFromPrompt(prompt);
    const difficulty = extractDifficultyFromPrompt(prompt);
    
    // Try Gemini first if available
    if (isGeminiConfigured()) {
      console.log('🤖 Attempting real AI question generation with Google Gemini...');
      const geminiQuestions = await tryGemini('questions', {
        subject: getSubjectDisplayName(subject),
        difficulty,
        count: requestedCount
      });
      
      if (geminiQuestions && geminiQuestions.length > 0) {
        console.log(`✅ Successfully generated ${geminiQuestions.length} questions with Gemini AI!`);
        return { questions: geminiQuestions };
      }
    }
    
    // Fallback to comprehensive local question bank
    console.log('📚 Using comprehensive local question bank...');
    try {
      const questions = await generateDynamicQuestions(prompt, requestedCount);
      console.log(`✅ Generated ${questions.length} questions from local bank`);
      return { questions };
    } catch (error) {
      console.error('Error generating questions from local bank:', error);
      // Emergency fallback with minimal questions
      const emergencyQuestions = getEmergencyQuestions(requestedCount);
      console.log('🆘 Using emergency fallback questions');
      return { questions: emergencyQuestions };
    }
  }

  // Mock response for feedback generation
  if (response_json_schema?.properties?.feedback) {
    return {
      feedback: "Great job on completing the quiz! You showed strong understanding in most areas. Focus on reviewing the topics where you had incorrect answers, and consider practicing more problems to reinforce your learning. Keep up the excellent work!",
      weak_topics: ["Time Complexity Analysis", "Pointer Arithmetic", "Algorithm Implementation"]
    };
  }

  // Mock response for insights generation
  if (response_json_schema?.properties?.insights) {
    return {
      insights: [
        {
          type: "strength",
          message: "You consistently perform well in algorithm design questions",
          subject: "dsa_c",
          action: "Continue practicing advanced algorithm problems"
        },
        {
          type: "weakness",
          message: "Time complexity analysis needs improvement",
          subject: "dsa_c",
          action: "Review Big-O notation and practice complexity calculations"
        },
        {
          type: "recommendation",
          message: "Try harder difficulty problems to challenge yourself",
          subject: "python",
          action: "Attempt advanced Python programming challenges"
        }
      ]
    };
  }

  // For chatbot responses (no schema provided)
  if (!response_json_schema) {
    // Try Gemini for chat responses if available
    if (isGeminiConfigured()) {
      console.log('💬 Attempting real AI chat response with Google Gemini...');
      const geminiResponse = await tryGemini('chat', {
        message: prompt,
        context: [], // Would need to pass actual chat context
        subject: null // Would extract from context
      });
      
      if (geminiResponse) {
        console.log('✅ Generated response with Gemini AI!');
        return geminiResponse;
      }
    }
    
    // Fallback to comprehensive local responses
    console.log('💭 Using local AI simulation...');
    
    try {
      // Intelligent response selection based on prompt keywords
      let response = getIntelligentResponse(prompt);
      console.log('✅ Generated local AI response');
      return response;
    } catch (error) {
      console.error('Error generating local response:', error);
      return "I'm here to help you learn! Feel free to ask me about programming concepts, algorithms, or data structures.";
    }
  }

  // Default fallback
  return "I'm ready to help with your questions! Feel free to ask about any programming concept, algorithm, or data structure.";
}

// Helper functions
function extractQuestionCount(prompt) {
  const match = prompt.match(/EXACTLY (\d+) /);
  return match ? parseInt(match[1]) : 10;
}

function getDetailedExplanation(prompt) {
  return "This is a fundamental concept in computer science. The key points to understand are: 1) The underlying theory, 2) Practical applications, 3) Common pitfalls to avoid. Let me know if you need more specific details!";
}

function getCodeHelp(prompt) {
  return "Looking at your code, I can help with syntax, logic, optimization, and best practices. Share your code and I'll provide detailed feedback and suggestions for improvement.";
}

function getPracticeProblems(prompt) {
  return "Here are some tailored practice problems: 1) Basic implementation problem, 2) Algorithm optimization challenge, 3) Debugging exercise. These will help reinforce your understanding!";
}

// Comprehensive question banks based on real educational sources
const QUESTION_BANKS = {
  dsa_c: {
    easy: [
      {
        question: "What is the time complexity of accessing an element in an array by index?",
        options: ["O(1)", "O(log n)", "O(n)", "O(n²)"],
        correct_answer: 0,
        explanation: "Array elements are stored in contiguous memory locations. Accessing an element by index involves simple pointer arithmetic: base_address + (index * element_size), which is a constant time operation regardless of array size.",
        source: { title: "Introduction to Algorithms - CLRS", url: "https://mitpress.mit.edu/books/introduction-algorithms" },
        difficulty_justification: "Basic array access is fundamental to understanding data structures",
        learning_objective: "Understanding array indexing and memory layout",
        tags: ["arrays", "time-complexity", "memory"]
      },
      {
        question: "Which of the following is true about a linked list?",
        options: ["Elements are stored in contiguous memory", "Random access is O(1)", "Insertion at beginning is O(1)", "Memory usage is always less than arrays"],
        correct_answer: 2,
        explanation: "In a linked list, insertion at the beginning requires only updating a few pointers: create new node, set its next to current head, update head to new node. This is constant time regardless of list size.",
        source: { title: "Data Structures Using C - Reema Thareja", url: "https://www.oxfordscholarship.com" },
        difficulty_justification: "Tests basic understanding of linked list operations",
        learning_objective: "Understanding pointer manipulation in linked structures",
        tags: ["linked-lists", "pointers", "insertion"]
      },
      {
        question: "What does the following C code print?\n```c\nint arr[] = {1,2,3,4,5};\nprintf(\"%d\", *(arr+2));\n```",
        options: ["2", "3", "Address of arr[2]", "Compilation error"],
        correct_answer: 1,
        explanation: "*(arr+2) is equivalent to arr[2]. The expression arr+2 gives the address of the 3rd element, and dereferencing it with * gives the value 3. This demonstrates pointer arithmetic in C.",
        source: { title: "The C Programming Language - K&R", url: "https://www.pearson.com" },
        difficulty_justification: "Basic pointer arithmetic with arrays",
        learning_objective: "Understanding relationship between arrays and pointers",
        tags: ["c-programming", "pointers", "arrays"]
      },
      {
        question: "Which data structure uses LIFO (Last In, First Out) principle?",
        options: ["Queue", "Stack", "Array", "Linked List"],
        correct_answer: 1,
        explanation: "Stack follows LIFO principle where the last element added is the first one to be removed. Common operations are push (add) and pop (remove) at the top. Examples include function call stack and expression evaluation.",
        source: { title: "Data Structures and Algorithms - Cormen", url: "https://mitpress.mit.edu" },
        difficulty_justification: "Basic understanding of stack data structure",
        learning_objective: "Understanding stack operations and principles",
        tags: ["stack", "data-structures", "lifo"]
      },
      {
        question: "What is the purpose of a hash function in a hash table?",
        options: ["Sort elements", "Map keys to indices", "Compare elements", "Encrypt data"],
        correct_answer: 1,
        explanation: "A hash function maps keys to array indices in a hash table, enabling O(1) average case access time. Good hash functions distribute keys uniformly to minimize collisions.",
        source: { title: "Introduction to Algorithms - CLRS", url: "https://mitpress.mit.edu" },
        difficulty_justification: "Fundamental concept in hash table implementation",
        learning_objective: "Understanding hash table mechanics",
        tags: ["hash-table", "hashing", "data-structures"]
      }
    ],
    medium: [
      {
        question: "What is the worst-case time complexity of QuickSort?",
        options: ["O(n log n)", "O(n²)", "O(n)", "O(log n)"],
        correct_answer: 1,
        explanation: "QuickSort's worst case occurs when the pivot is always the smallest or largest element, leading to unbalanced partitions. This results in O(n²) comparisons. However, with good pivot selection (like median-of-three), this is rare in practice.",
        source: { title: "Algorithms - Sedgewick & Wayne", url: "https://algs4.cs.princeton.edu" },
        difficulty_justification: "Requires understanding of algorithm analysis and worst-case scenarios",
        learning_objective: "Analyzing sorting algorithm complexities",
        tags: ["sorting", "quicksort", "complexity-analysis"]
      },
      {
        question: "Which traversal of a Binary Search Tree gives elements in sorted order?",
        options: ["Preorder", "Inorder", "Postorder", "Level order"],
        correct_answer: 1,
        explanation: "Inorder traversal (left-root-right) of a BST visits nodes in ascending order because of the BST property: left subtree < root < right subtree. This is the basis for many BST algorithms.",
        source: { title: "Data Structures and Algorithms - Aho, Hopcroft, Ullman", url: "https://www.pearsonhighered.com" },
        difficulty_justification: "Requires understanding tree traversal algorithms and BST properties",
        learning_objective: "Understanding tree traversal patterns and their applications",
        tags: ["binary-trees", "traversal", "sorting"]
      },
      {
        question: "What is the space complexity of merge sort?",
        options: ["O(1)", "O(log n)", "O(n)", "O(n²)"],
        correct_answer: 2,
        explanation: "Merge sort requires O(n) additional space for the temporary arrays used during the merge process. Although it can be implemented with O(log n) space using in-place merging, the standard implementation uses O(n) extra space.",
        source: { title: "Algorithm Design - Kleinberg & Tardos", url: "https://www.pearson.com" },
        difficulty_justification: "Requires understanding of space complexity analysis",
        learning_objective: "Analyzing space requirements of recursive algorithms",
        tags: ["merge-sort", "space-complexity", "recursion"]
      },
      {
        question: "In a max heap, what is the relationship between a parent node and its children?",
        options: ["Parent < Children", "Parent > Children", "Parent = Children", "No specific relationship"],
        correct_answer: 1,
        explanation: "In a max heap, every parent node has a value greater than or equal to its children. This heap property ensures the maximum element is always at the root, making it useful for priority queues and heap sort.",
        source: { title: "Introduction to Algorithms - CLRS", url: "https://mitpress.mit.edu" },
        difficulty_justification: "Understanding heap properties and structure",
        learning_objective: "Learning heap data structure properties",
        tags: ["heap", "binary-tree", "priority-queue"]
      }
    ],
    hard: [
      {
        question: "What is the minimum number of comparisons needed to find both maximum and minimum elements in an unsorted array of n elements?",
        options: ["2n - 2", "3n/2 - 2", "n - 1", "n + 1"],
        correct_answer: 1,
        explanation: "By comparing elements in pairs and then comparing the larger with max and smaller with min, we need n/2 comparisons for pairing + (n/2 - 1) for max + (n/2 - 1) for min = 3n/2 - 2 total comparisons. This is optimal.",
        source: { title: "Introduction to Algorithms - CLRS (Chapter 9)", url: "https://mitpress.mit.edu/books/introduction-algorithms" },
        difficulty_justification: "Requires advanced analysis of comparison-based algorithms",
        learning_objective: "Understanding optimal algorithm design and analysis",
        tags: ["optimization", "comparison-algorithms", "analysis"]
      }
    ]
  },
  oops_cpp: {
    easy: [
      {
        question: "What is encapsulation in object-oriented programming?",
        options: ["Inheriting from multiple classes", "Bundling data and methods together", "Creating multiple objects", "Overloading operators"],
        correct_answer: 1,
        explanation: "Encapsulation is the bundling of data (attributes) and methods (functions) that operate on that data into a single unit (class). It also involves hiding internal implementation details from outside access, promoting modularity and security.",
        source: { title: "Object-Oriented Programming in C++ - Robert Lafore", url: "https://www.pearson.com" },
        difficulty_justification: "Fundamental OOP concept that beginners must understand",
        learning_objective: "Understanding core OOP principles",
        tags: ["oop", "encapsulation", "design-principles"]
      },
      {
        question: "What is the output of this C++ code?\n```cpp\nclass Base {\npublic: int x = 10;\n};\nclass Derived : public Base {\npublic: int x = 20;\n};\nDerived d;\ncout << d.x;\n```",
        options: ["10", "20", "Compilation error", "Runtime error"],
        correct_answer: 1,
        explanation: "In this case, the derived class has its own member variable x that shadows the base class member. When accessing d.x, it refers to Derived::x, which is 20. The base class member is hidden but still exists.",
        source: { title: "C++ Primer - Lippman, Lajoie, Moo", url: "https://www.pearson.com" },
        difficulty_justification: "Tests understanding of member hiding vs overriding",
        learning_objective: "Understanding inheritance and name resolution",
        tags: ["cpp", "inheritance", "member-hiding"]
      },
      {
        question: "What is a copy constructor in C++?",
        options: ["A constructor that takes no parameters", "A constructor that takes an object of the same class as parameter", "A constructor that copies files", "A virtual constructor"],
        correct_answer: 1,
        explanation: "A copy constructor is a special constructor that creates a new object as a copy of an existing object. It takes a const reference to an object of the same class as its parameter and is called during object initialization, function parameter passing, and return by value.",
        source: { title: "Effective C++ - Scott Meyers", url: "https://www.oreilly.com" },
        difficulty_justification: "Basic understanding of special member functions",
        learning_objective: "Understanding object copying mechanisms in C++",
        tags: ["cpp", "copy-constructor", "object-copying"]
      },
      {
        question: "What is the purpose of the 'virtual' keyword in C++?",
        options: ["Make variables global", "Enable runtime polymorphism", "Optimize performance", "Prevent inheritance"],
        correct_answer: 1,
        explanation: "The 'virtual' keyword enables runtime polymorphism in C++. Virtual functions allow derived classes to override base class methods, and the correct version is called based on the actual object type at runtime, not the pointer/reference type.",
        source: { title: "The C++ Programming Language - Stroustrup", url: "https://www.pearson.com" },
        difficulty_justification: "Core concept in object-oriented programming",
        learning_objective: "Understanding virtual functions and polymorphism",
        tags: ["cpp", "virtual-functions", "polymorphism"]
      }
    ],
    medium: [
      {
        question: "What is the difference between function overloading and function overriding?",
        options: ["No difference", "Overloading is compile-time, overriding is runtime", "Overloading is runtime, overriding is compile-time", "Both occur at the same time"],
        correct_answer: 1,
        explanation: "Function overloading is resolved at compile-time based on function signatures (static polymorphism). Function overriding occurs at runtime through virtual function calls (dynamic polymorphism), allowing different implementations in derived classes.",
        source: { title: "Effective C++ - Scott Meyers", url: "https://www.oreilly.com" },
        difficulty_justification: "Requires understanding of polymorphism types",
        learning_objective: "Distinguishing between static and dynamic polymorphism",
        tags: ["polymorphism", "overloading", "overriding"]
      }
    ],
    hard: [
      {
        question: "What happens when you call a virtual function from a constructor?",
        options: ["Calls derived class version", "Calls base class version", "Compilation error", "Undefined behavior"],
        correct_answer: 1,
        explanation: "During construction, the object is not yet fully formed. Virtual function calls from constructors are resolved to the current class being constructed, not derived classes. This prevents calling functions on incompletely initialized objects.",
        source: { title: "More Effective C++ - Scott Meyers", url: "https://www.oreilly.com" },
        difficulty_justification: "Advanced concept about object lifecycle and virtual dispatch",
        learning_objective: "Understanding constructor behavior and virtual function dispatch",
        tags: ["virtual-functions", "constructors", "object-lifecycle"]
      }
    ]
  },
  python: {
    easy: [
      {
        question: "What is the output of: print(type([1, 2, 3]))",
        options: ["<class 'list'>", "<class 'array'>", "<class 'tuple'>", "list"],
        correct_answer: 0,
        explanation: "The type() function returns the exact type of an object. [1, 2, 3] creates a list object, so type() returns <class 'list'>. This is different from isinstance() which checks inheritance hierarchy.",
        source: { title: "Python Documentation - Built-in Functions", url: "https://docs.python.org/3/library/functions.html" },
        difficulty_justification: "Basic Python syntax and built-in functions",
        learning_objective: "Understanding Python data types and introspection",
        tags: ["python", "data-types", "built-ins"]
      },
      {
        question: "What does the 'pass' statement do in Python?",
        options: ["Skips the current iteration", "Does nothing (null operation)", "Passes a variable", "Exits the program"],
        correct_answer: 1,
        explanation: "The 'pass' statement is a null operation in Python. It does nothing and is used as a placeholder where syntactically some code is required, but no action needs to be performed. It's commonly used in empty functions, classes, or control structures.",
        source: { title: "Python Documentation - Simple Statements", url: "https://docs.python.org/3/reference/simple_stmts.html" },
        difficulty_justification: "Basic Python syntax understanding",
        learning_objective: "Understanding Python placeholder statements",
        tags: ["python", "syntax", "statements"]
      },
      {
        question: "Which method is used to add an element to a Python list?",
        options: ["add()", "append()", "insert()", "Both append() and insert()"],
        correct_answer: 3,
        explanation: "Both append() and insert() can add elements to a list. append() adds an element to the end, while insert() adds an element at a specific position. The add() method is used for sets, not lists.",
        source: { title: "Python Data Structures", url: "https://docs.python.org/3/tutorial/datastructures.html" },
        difficulty_justification: "Understanding list methods and operations",
        learning_objective: "Learning Python list manipulation methods",
        tags: ["python", "lists", "methods"]
      }
    ],
    medium: [
      {
        question: "What is the difference between '==' and 'is' in Python?",
        options: ["No difference", "== checks value equality, 'is' checks identity", "'is' checks value equality, == checks identity", "Both check identity"],
        correct_answer: 1,
        explanation: "The == operator checks if two objects have the same value (calls __eq__ method). The 'is' operator checks if two variables refer to the same object in memory (identity comparison). For example, two lists with same contents are == but not 'is'.",
        source: { title: "Fluent Python - Luciano Ramalho", url: "https://www.oreilly.com" },
        difficulty_justification: "Important distinction that affects program correctness",
        learning_objective: "Understanding Python object model and comparison operators",
        tags: ["python", "operators", "object-identity"]
      }
    ],
    hard: [
      {
        question: "What will this code output?\n```python\nclass Meta(type):\n    def __new__(cls, name, bases, dct):\n        dct['added'] = True\n        return super().__new__(cls, name, bases, dct)\n\nclass MyClass(metaclass=Meta):\n    pass\n\nprint(hasattr(MyClass, 'added'))\n```",
        options: ["True", "False", "AttributeError", "TypeError"],
        correct_answer: 0,
        explanation: "Metaclasses control class creation. The Meta metaclass modifies the class dictionary during creation, adding 'added': True. This attribute becomes part of MyClass, so hasattr(MyClass, 'added') returns True.",
        source: { title: "Python Tricks - Dan Bader", url: "https://realpython.com" },
        difficulty_justification: "Advanced topic requiring deep understanding of Python's class creation process",
        learning_objective: "Understanding metaclasses and class customization",
        tags: ["metaclasses", "class-creation", "advanced-python"]
      }
    ]
  },
  java: {
    easy: [
      {
        question: "Which method is called when an object is created in Java?",
        options: ["main()", "constructor", "init()", "create()"],
        correct_answer: 1,
        explanation: "Constructors are special methods called automatically when an object is instantiated using 'new'. They initialize the object's state and have the same name as the class with no return type.",
        source: { title: "Java: The Complete Reference - Herbert Schildt", url: "https://www.oraclepress.com" },
        difficulty_justification: "Fundamental Java concept about object creation",
        learning_objective: "Understanding object lifecycle in Java",
        tags: ["java", "constructors", "object-creation"]
      },
      {
        question: "What is the difference between JDK, JRE, and JVM?",
        options: ["They are the same thing", "JDK contains JRE, JRE contains JVM", "JVM contains JRE, JRE contains JDK", "They are completely separate"],
        correct_answer: 1,
        explanation: "JDK (Java Development Kit) is the complete development toolkit containing compiler, debugger, and other tools. JRE (Java Runtime Environment) is the runtime environment for Java applications. JVM (Java Virtual Machine) executes Java bytecode. JDK contains JRE, and JRE contains JVM.",
        source: { title: "Java Platform Overview", url: "https://docs.oracle.com/javase/8/docs/" },
        difficulty_justification: "Understanding Java platform components",
        learning_objective: "Learning Java ecosystem architecture",
        tags: ["java", "jdk", "jre", "jvm"]
      },
      {
        question: "Which access modifier makes a member visible only within the same package?",
        options: ["private", "protected", "public", "default (no modifier)"],
        correct_answer: 3,
        explanation: "The default access modifier (no explicit modifier) makes a member package-private, meaning it's accessible only within the same package. Private is class-only, protected allows subclasses, and public allows access from anywhere.",
        source: { title: "Java Language Specification", url: "https://docs.oracle.com/javase/specs/" },
        difficulty_justification: "Understanding Java access control",
        learning_objective: "Learning Java visibility modifiers",
        tags: ["java", "access-modifiers", "encapsulation"]
      }
    ],
    medium: [
      {
        question: "What is the difference between ArrayList and LinkedList in Java?",
        options: ["No difference", "ArrayList uses arrays, LinkedList uses nodes", "ArrayList is slower", "LinkedList doesn't allow duplicates"],
        correct_answer: 1,
        explanation: "ArrayList internally uses a dynamic array, providing O(1) random access but O(n) insertion/deletion in middle. LinkedList uses doubly-linked nodes, providing O(1) insertion/deletion at ends but O(n) random access.",
        source: { title: "Effective Java - Joshua Bloch", url: "https://www.oreilly.com" },
        difficulty_justification: "Requires understanding of data structure implementations",
        learning_objective: "Comparing Java collection performance characteristics",
        tags: ["java", "collections", "data-structures"]
      }
    ],
    hard: [
      {
        question: "What happens when you modify a List while iterating over it with an enhanced for loop?",
        options: ["Works normally", "ConcurrentModificationException", "NullPointerException", "Compilation error"],
        correct_answer: 1,
        explanation: "Enhanced for loops use iterators internally. Modifying the collection during iteration (except through iterator's remove() method) causes ConcurrentModificationException as a fail-fast mechanism to prevent inconsistent state.",
        source: { title: "Java Concurrency in Practice - Brian Goetz", url: "https://www.pearson.com" },
        difficulty_justification: "Advanced concept about iterator behavior and thread safety",
        learning_objective: "Understanding fail-fast iterators and concurrent modification",
        tags: ["java", "iterators", "exceptions"]
      }
    ]
  },
  c_language: {
    easy: [
      {
        question: "What is the size of 'int' data type in most modern systems?",
        options: ["2 bytes", "4 bytes", "8 bytes", "Depends on compiler"],
        correct_answer: 1,
        explanation: "In most modern 32-bit and 64-bit systems, 'int' is typically 4 bytes (32 bits). However, the C standard only guarantees minimum sizes, so it can vary by platform. Use sizeof(int) to check on your system.",
        source: { title: "The C Programming Language - Kernighan & Ritchie", url: "https://www.pearson.com" },
        difficulty_justification: "Basic understanding of C data types",
        learning_objective: "Understanding primitive data types and memory layout",
        tags: ["c-language", "data-types", "memory"]
      }
    ],
    medium: [
      {
        question: "What is the difference between malloc() and calloc()?",
        options: ["No difference", "malloc initializes to zero, calloc doesn't", "calloc initializes to zero, malloc doesn't", "malloc is faster"],
        correct_answer: 2,
        explanation: "calloc() allocates memory and initializes all bytes to zero, while malloc() allocates uninitialized memory (contains garbage values). calloc() also takes two parameters (count and size) while malloc() takes one (total size).",
        source: { title: "C Programming: A Modern Approach - K.N. King", url: "https://www.norton.com" },
        difficulty_justification: "Important for understanding dynamic memory management",
        learning_objective: "Understanding different memory allocation functions",
        tags: ["c-language", "memory-management", "malloc"]
      }
    ],
    hard: [
      {
        question: "What is undefined behavior in this code: char *p = \"hello\"; *p = 'H';",
        options: ["No undefined behavior", "Modifying string literal", "Null pointer dereference", "Buffer overflow"],
        correct_answer: 1,
        explanation: "String literals are stored in read-only memory in most implementations. Attempting to modify them through a pointer results in undefined behavior. Use char p[] = \"hello\"; for modifiable strings.",
        source: { title: "Expert C Programming - Peter van der Linden", url: "https://www.pearson.com" },
        difficulty_justification: "Advanced concept about memory segments and undefined behavior",
        learning_objective: "Understanding string literals and memory protection",
        tags: ["c-language", "undefined-behavior", "string-literals"]
      }
    ]
  },
  software_engineering: {
    easy: [
      {
        question: "What is the main purpose of version control systems?",
        options: ["Compile code faster", "Track changes in code over time", "Debug programs", "Test applications"],
        correct_answer: 1,
        explanation: "Version control systems like Git track changes to files over time, allowing developers to see history, revert changes, collaborate effectively, and manage different versions of software projects.",
        source: { title: "Software Engineering - Ian Sommerville", url: "https://www.pearson.com" },
        difficulty_justification: "Fundamental software development practice",
        learning_objective: "Understanding essential development tools",
        tags: ["version-control", "software-development", "collaboration"]
      }
    ],
    medium: [
      {
        question: "What is the Single Responsibility Principle (SRP)?",
        options: ["A class should have only one method", "A class should have only one reason to change", "A program should have only one class", "A method should return only one value"],
        correct_answer: 1,
        explanation: "The Single Responsibility Principle states that a class should have only one reason to change, meaning it should have only one job or responsibility. This makes code more maintainable and less coupled.",
        source: { title: "Clean Code - Robert C. Martin", url: "https://www.oreilly.com" },
        difficulty_justification: "Requires understanding of SOLID principles",
        learning_objective: "Understanding software design principles",
        tags: ["solid-principles", "design", "clean-code"]
      }
    ],
    hard: [
      {
        question: "In microservices architecture, what is the Database-per-Service pattern?",
        options: ["All services share one database", "Each service has its own database", "Services don't use databases", "Only one service can access the database"],
        correct_answer: 1,
        explanation: "Database-per-Service means each microservice has its own private database that cannot be accessed directly by other services. This ensures loose coupling and allows services to evolve independently, though it introduces challenges like distributed transactions.",
        source: { title: "Microservices Patterns - Chris Richardson", url: "https://www.manning.com" },
        difficulty_justification: "Advanced architectural concept requiring understanding of distributed systems",
        learning_objective: "Understanding microservices design patterns",
        tags: ["microservices", "architecture", "databases"]
      }
    ]
  },
  digital_electronics: {
    easy: [
      {
        question: "How many input combinations are possible with 3 binary inputs?",
        options: ["3", "6", "8", "9"],
        correct_answer: 2,
        explanation: "With n binary inputs, there are 2^n possible combinations. For 3 inputs, that's 2^3 = 8 combinations: 000, 001, 010, 011, 100, 101, 110, 111.",
        source: { title: "Digital Design - Morris Mano", url: "https://www.pearson.com" },
        difficulty_justification: "Basic combinatorial logic concept",
        learning_objective: "Understanding binary number systems and combinations",
        tags: ["binary", "combinatorial-logic", "truth-tables"]
      }
    ],
    medium: [
      {
        question: "What is the main advantage of Gray code over binary code?",
        options: ["Faster computation", "Only one bit changes between consecutive numbers", "Uses fewer bits", "Easier to understand"],
        correct_answer: 1,
        explanation: "Gray code is designed so that only one bit changes when moving from one number to the next consecutive number. This reduces errors in mechanical encoders and eliminates glitches in digital circuits during state transitions.",
        source: { title: "Digital Electronics - Anil K. Maini", url: "https://www.wiley.com" },
        difficulty_justification: "Requires understanding of encoding schemes and their applications",
        learning_objective: "Understanding different number encoding systems",
        tags: ["gray-code", "encoding", "error-reduction"]
      }
    ],
    hard: [
      {
        question: "In a 4-bit ripple carry adder, what is the worst-case propagation delay?",
        options: ["1 gate delay", "4 gate delays", "8 gate delays", "16 gate delays"],
        correct_answer: 2,
        explanation: "In a ripple carry adder, the carry must propagate through all stages. For a 4-bit adder, the worst case is when carry propagates from LSB to MSB, requiring 2 gate delays per stage (XOR + AND/OR) × 4 stages = 8 gate delays total.",
        source: { title: "Computer Architecture - Hennessy & Patterson", url: "https://www.elsevier.com" },
        difficulty_justification: "Advanced timing analysis requiring understanding of propagation delays",
        learning_objective: "Analyzing sequential circuit timing and optimization",
        tags: ["timing-analysis", "adders", "propagation-delay"]
      }
    ]
  }
};

// Dynamic question generation function with improved deduplication
async function generateDynamicQuestions(prompt, requestedCount) {
  // Extract subject and difficulty from prompt
  const subject = extractSubjectFromPrompt(prompt);
  const difficulty = extractDifficultyFromPrompt(prompt);
  
  console.log(`Generating ${requestedCount} questions for ${subject} at ${difficulty} level`);
  
  // Get available questions for the subject and difficulty
  let availableQuestions = [...(QUESTION_BANKS[subject]?.[difficulty] || [])];
  
  if (availableQuestions.length === 0) {
    // Fallback to any difficulty if specific level not available
    const allDifficulties = ['easy', 'medium', 'hard'];
    for (const diff of allDifficulties) {
      availableQuestions.push(...(QUESTION_BANKS[subject]?.[diff] || []));
    }
  }
  
  // Shuffle the entire array first to ensure randomness
  availableQuestions = shuffleArray(availableQuestions);
  
  const questions = [];
  const usedQuestions = new Set(); // Track used question text to avoid exact duplicates
  const usedConcepts = new Set(); // Track used concepts to avoid similar questions
  
  // First, try to use unique questions from the bank
  for (const question of availableQuestions) {
    if (questions.length >= requestedCount) break;
    
    const normalizedQuestion = normalizeQuestionText(question.question);
    
    // Skip if we've seen this exact question
    if (usedQuestions.has(normalizedQuestion)) {
      continue;
    }
    
    // Extract key concepts and check for similarity
    const concepts = extractKeyConcepts(normalizedQuestion);
    const conceptKey = concepts.sort().join('|');
    
    // Allow some concept overlap, but not if it's the primary concept
    if (conceptKey && usedConcepts.has(conceptKey) && concepts.length <= 2) {
      continue;
    }
    
    usedQuestions.add(normalizedQuestion);
    if (conceptKey) usedConcepts.add(conceptKey);
    questions.push({ ...question });
  }
  
  // If we still need more questions, generate variations or new ones
  while (questions.length < requestedCount) {
    let newQuestion;
    
    if (availableQuestions.length > 0) {
      // Create a variation of an existing question
      const baseQuestion = availableQuestions[Math.floor(Math.random() * availableQuestions.length)];
      newQuestion = await createQuestionVariation(baseQuestion, subject, difficulty);
    } else {
      // Generate a completely new question
      newQuestion = await generateNewQuestion(subject, difficulty);
    }
    
    // Ensure the new question is unique
    const normalizedNew = normalizeQuestionText(newQuestion.question);
    if (!usedQuestions.has(normalizedNew)) {
      usedQuestions.add(normalizedNew);
      questions.push(newQuestion);
    }
  }
  
  return questions;
}

function extractSubjectFromPrompt(prompt) {
  const subjects = {
    'DSA (C)': 'dsa_c',
    'OOPS (C++)': 'oops_cpp', 
    'Software Engineering': 'software_engineering',
    'C Language': 'c_language',
    'Digital Electronics': 'digital_electronics',
    'JAVA': 'java',
    'Python': 'python'
  };
  
  for (const [name, key] of Object.entries(subjects)) {
    if (prompt.includes(name)) return key;
  }
  
  return 'dsa_c'; // default
}

function getSubjectDisplayName(subjectKey) {
  const displayNames = {
    'dsa_c': 'Data Structures and Algorithms (C)',
    'oops_cpp': 'Object-Oriented Programming (C++)',
    'software_engineering': 'Software Engineering',
    'c_language': 'C Programming Language',
    'digital_electronics': 'Digital Electronics',
    'java': 'Java Programming',
    'python': 'Python Programming'
  };
  return displayNames[subjectKey] || 'Computer Science';
}

function extractDifficultyFromPrompt(prompt) {
  if (prompt.includes('easy')) return 'easy';
  if (prompt.includes('hard')) return 'hard';
  return 'medium'; // default
}

async function createQuestionVariation(baseQuestion, subject, difficulty) {
  // Create meaningful variations in existing questions to avoid repetition
  const variation = { ...baseQuestion };
  
  // Generate variations based on subject and question type
  if (subject === 'dsa_c') {
    if (baseQuestion.question.includes('time complexity')) {
      const algorithms = [
        { name: 'binary search', complexity: 'O(log n)', type: 'searching' },
        { name: 'linear search', complexity: 'O(n)', type: 'searching' },
        { name: 'merge sort', complexity: 'O(n log n)', type: 'sorting' },
        { name: 'bubble sort', complexity: 'O(n²)', type: 'sorting' },
        { name: 'insertion sort', complexity: 'O(n²)', type: 'sorting' },
        { name: 'heap sort', complexity: 'O(n log n)', type: 'sorting' }
      ];
      const randomAlgorithm = algorithms[Math.floor(Math.random() * algorithms.length)];
      variation.question = `What is the worst-case time complexity of ${randomAlgorithm.name}?`;
      
      // Update options and correct answer based on the algorithm
      const complexityOptions = ['O(1)', 'O(log n)', 'O(n)', 'O(n log n)', 'O(n²)'];
      variation.options = shuffleArray(complexityOptions).slice(0, 4);
      variation.correct_answer = variation.options.indexOf(randomAlgorithm.complexity);
      if (variation.correct_answer === -1) {
        variation.options[0] = randomAlgorithm.complexity;
        variation.correct_answer = 0;
      }
      
      variation.explanation = `${randomAlgorithm.name} has a worst-case time complexity of ${randomAlgorithm.complexity}. This is because...`;
    } else if (baseQuestion.question.includes('data structure')) {
      const dataStructures = ['array', 'linked list', 'binary tree', 'hash table', 'stack', 'queue'];
      const randomDS = dataStructures[Math.floor(Math.random() * dataStructures.length)];
      variation.question = `Which operation is most efficient in a ${randomDS}?`;
    }
  } else if (subject === 'oops_cpp') {
    if (baseQuestion.question.includes('inheritance')) {
      const concepts = ['virtual functions', 'abstract classes', 'multiple inheritance', 'diamond problem'];
      const randomConcept = concepts[Math.floor(Math.random() * concepts.length)];
      variation.question = `What is the main purpose of ${randomConcept} in C++?`;
    }
  } else if (subject === 'python') {
    if (baseQuestion.question.includes('data type')) {
      const dataTypes = ['list', 'tuple', 'dict', 'set', 'frozenset'];
      const randomType = dataTypes[Math.floor(Math.random() * dataTypes.length)];
      variation.question = `Which of the following best describes a Python ${randomType}?`;
    }
  }
  
  // Add variation indicator and ensure uniqueness
  variation.id = 'var_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
  variation.tags = [...(baseQuestion.tags || []), 'variation'];
  
  return variation;
}

async function generateNewQuestion(subject, difficulty) {
  // Generate completely new questions when we run out of predefined ones
  const templates = {
    dsa_c: {
      question: "What is the space complexity of a recursive implementation of factorial?",
      options: ["O(1)", "O(n)", "O(log n)", "O(n²)"],
      correct_answer: 1,
      explanation: "Recursive factorial creates n function calls on the call stack (one for each number from n down to 1), requiring O(n) space for the stack frames.",
      source: { title: "Algorithm Analysis - Generated", url: "https://algorithms.example.com" }
    },
    python: {
      question: "Which Python data structure maintains insertion order?",
      options: ["set", "frozenset", "dict (Python 3.7+)", "tuple"],
      correct_answer: 2,
      explanation: "Since Python 3.7, dictionaries maintain insertion order as part of the language specification, not just implementation detail.",
      source: { title: "Python Documentation - Generated", url: "https://docs.python.org" }
    }
  };
  
  const template = templates[subject] || templates.dsa_c;
  return {
    ...template,
    difficulty_justification: `Generated question for ${difficulty} level`,
    learning_objective: `Understanding ${subject} concepts`,
    tags: [subject, difficulty, "generated"],
    id: 'gen_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5)
  };
}

// Emergency fallback questions when all else fails
function getEmergencyQuestions(count) {
  const emergencyQuestions = [
    {
      question: "What does 'algorithm' mean in computer science?",
      options: ["A step-by-step procedure to solve a problem", "A programming language", "A type of computer", "A software application"],
      correct_answer: 0,
      explanation: "An algorithm is a finite sequence of well-defined instructions used to solve a problem or perform a computation.",
      source: { title: "Computer Science Fundamentals", url: "https://example.com" },
      difficulty_justification: "Basic definition question",
      learning_objective: "Understanding fundamental CS concepts",
      tags: ["basic", "definitions"]
    },
    {
      question: "Which of the following is a programming language?",
      options: ["HTML", "CSS", "Python", "JSON"],
      correct_answer: 2,
      explanation: "Python is a high-level programming language. HTML and CSS are markup/styling languages, while JSON is a data format.",
      source: { title: "Programming Languages Overview", url: "https://example.com" },
      difficulty_justification: "Basic language identification",
      learning_objective: "Distinguishing programming languages from other technologies",
      tags: ["basic", "languages"]
    }
  ];
  
  const questions = [];
  for (let i = 0; i < count; i++) {
    questions.push({ ...emergencyQuestions[i % emergencyQuestions.length], id: `emergency_${i}` });
  }
  return questions;
}

// Helper functions for question deduplication
function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

function normalizeQuestionText(questionText) {
  return questionText
    .toLowerCase()
    .replace(/[^a-z0-9]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractKeyConcepts(normalizedText) {
  // Common programming/CS concepts to look for
  const concepts = [
    'time complexity', 'space complexity', 'big o', 'algorithm', 'data structure',
    'array', 'linked list', 'stack', 'queue', 'tree', 'graph', 'hash table',
    'sorting', 'searching', 'recursion', 'dynamic programming', 'greedy',
    'binary search', 'quicksort', 'mergesort', 'bubblesort', 'heap', 'bst',
    'inheritance', 'polymorphism', 'encapsulation', 'abstraction',
    'constructor', 'destructor', 'virtual function', 'overloading', 'overriding',
    'malloc', 'calloc', 'pointer', 'reference', 'memory', 'garbage collection',
    'exception', 'thread', 'synchronization', 'deadlock',
    'database', 'sql', 'transaction', 'normalization',
    'testing', 'debugging', 'version control', 'design pattern',
    'binary', 'decimal', 'hexadecimal', 'logic gate', 'boolean',
    'circuit', 'truth table', 'karnaugh map', 'flip flop'
  ];
  
  const foundConcepts = [];
  for (const concept of concepts) {
    if (normalizedText.includes(concept)) {
      foundConcepts.push(concept);
    }
  }
  
  return foundConcepts;
}

// Intelligent response generation based on keywords
function getIntelligentResponse(prompt) {
  const lowerPrompt = prompt.toLowerCase();
  
  if (lowerPrompt.includes('explain')) {
    return "Let me explain this concept in detail: " + getDetailedExplanation(prompt);
  } else if (lowerPrompt.includes('code')) {
    return "I can help you with code analysis. " + getCodeHelp(prompt);
  } else if (lowerPrompt.includes('practice')) {
    return "Here are some practice problems for you: " + getPracticeProblems(prompt);
  } else if (lowerPrompt.includes('time complexity') || lowerPrompt.includes('big o')) {
    return "Time complexity analysis is crucial for algorithm design. Let me break this down: Big O notation describes the upper bound of how an algorithm's runtime grows with input size. For example, O(n) means linear growth, O(log n) means logarithmic growth (very efficient), and O(n²) means quadratic growth (less efficient for large inputs). Which specific algorithm would you like me to analyze?";
  } else if (lowerPrompt.includes('recursion')) {
    return "Recursion is a powerful programming technique! Think of it like a Russian doll - each doll contains a smaller version of itself. In programming, a recursive function calls itself with a simpler version of the problem until it reaches a base case. The key components are: 1) Base case (when to stop), 2) Recursive case (how to break down the problem). What specific aspect of recursion would you like to explore?";
  } else if (lowerPrompt.includes('data structure')) {
    return "Data structures are the building blocks of efficient programs! Each structure has its strengths: Arrays for fast access, Linked Lists for flexible insertion/deletion, Stacks for LIFO operations, Queues for FIFO, Trees for hierarchical data, and Hash Tables for fast lookups. The choice depends on what operations you need to optimize. Which data structure are you curious about?";
  } else if (lowerPrompt.includes('binary search')) {
    return "Binary search is an efficient algorithm for finding a target value in a sorted array. It works by repeatedly dividing the search interval in half. If the target value is less than the middle element, search the left half; otherwise, search the right half. This gives us O(log n) time complexity - much better than linear search's O(n)!";
  } else if (lowerPrompt.includes('sorting')) {
    return "Sorting algorithms arrange data in a particular order. Here are some key ones: Bubble Sort (O(n²), simple but slow), Merge Sort (O(n log n), stable and predictable), Quick Sort (O(n log n) average, O(n²) worst case), and Heap Sort (O(n log n), in-place). Each has trade-offs between time complexity, space complexity, and stability. What specific sorting algorithm interests you?";
  } else if (lowerPrompt.includes('linked list')) {
    return "Linked lists are dynamic data structures where elements (nodes) are connected via pointers. Unlike arrays, they don't require contiguous memory. Advantages: dynamic size, efficient insertion/deletion at beginning. Disadvantages: no random access, extra memory for pointers. There are singly linked, doubly linked, and circular variants. What aspect would you like to explore?";
  }
  
  // Default responses for general queries
  const responses = [
    "I'm here to help you learn! What specific topic would you like to explore?",
    "That's a great question! Let me break it down for you step by step.",
    "I can see you're working on understanding this concept. Here's a detailed explanation...",
    "Based on your quiz performance, I recommend focusing on these areas for improvement.",
    "Let me provide you with some practice problems to reinforce your understanding.",
    "Excellent question! This is a fundamental concept that many students find challenging."
  ];
  
  return responses[Math.floor(Math.random() * responses.length)];
}
