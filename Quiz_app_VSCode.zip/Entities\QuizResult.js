{
  "name": "QuizResult",
  "type": "object",
  "properties": {
    "subject": {
      "type": "string",
      "enum": [
        "dsa_c",
        "oops_cpp",
        "software_engineering",
        "c_language",
        "digital_electronics",
        "java",
        "python"
      ]
    },
    "difficulty": {
      "type": "string",
      "enum": [
        "easy",
        "medium",
        "hard"
      ]
    },
    "score": {
      "type": "number",
      "minimum": 0,
      "maximum": 100
    },
    "total_questions": {
      "type": "number"
    },
    "correct_answers": {
      "type": "number"
    },
    "time_taken": {
      "type": "number",
      "description": "Time taken in seconds"
    },
    "questions_data": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "question": {
            "type": "string"
          },
          "options": {
            "type": "array",
            "items": {
              "type": "string"
            }
          },
          "correct_answer": {
            "type": "number"
          },
          "user_answer": {
            "type": "number"
          },
          "explanation": {
            "type": "string"
          },
          "source": {
            "type": "object",
            "properties": {
              "title": {
                "type": "string"
              },
              "url": {
                "type": "string"
              }
            }
          }
        }
      }
    },
    "weak_topics": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "ai_feedback": {
      "type": "string",
      "description": "Personalized AI feedback"
    }
  },
  "required": [
    "subject",
    "difficulty",
    "score",
    "total_questions",
    "correct_answers"
  ],
  "rls": {
    "read": {
      "$or": [
        {
          "created_by": "{{user.email}}"
        },
        {
          "user_condition": {
            "role": "admin"
          }
        }
      ]
    },
    "write": {
      "$or": [
        {
          "created_by": "{{user.email}}"
        },
        {
          "user_condition": {
            "role": "admin"
          }
        }
      ]
    }
  }
}