import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { QuizResult } from "@/entities/all";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { format } from "date-fns";
import {
  BookOpen,
  Brain,
  Trophy,
  ArrowLeft,
  CheckCircle,
  XCircle,
  Lightbulb,
  Link as LinkIcon
} from "lucide-react";

const subjects = {
  dsa_c: { name: "DSA (C)", color: "from-blue-500 to-cyan-500", icon: "🔢" },
  oops_cpp: { name: "OOPS (C++)", color: "from-purple-500 to-pink-500", icon: "🎯" },
  software_engineering: { name: "Software Engineering", color: "from-green-500 to-emerald-500", icon: "⚙️" },
  c_language: { name: "C Language", color: "from-orange-500 to-red-500", icon: "💻" },
  digital_electronics: { name: "Digital Electronics", color: "from-indigo-500 to-purple-500", icon: "⚡" },
  java: { name: "JAVA", color: "from-red-500 to-pink-500", icon: "☕" },
  python: { name: "Python", color: "from-yellow-500 to-orange-500", icon: "🐍" }
};

export default function ReportPage() {
  const [quizResult, setQuizResult] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadResult = async () => {
      try {
        const urlParams = new URLSearchParams(window.location.search);
        const id = urlParams.get('id');
        if (id) {
          const results = await QuizResult.filter({ id: id });
          if (results.length > 0) {
            setQuizResult(results[0]);
          }
        }
      } catch (error) {
        console.error("Error loading quiz result:", error);
      }
      setIsLoading(false);
    };

    loadResult();
  }, []);

  if (isLoading) {
    return (
      <div className="p-8 bg-gray-50 dark:bg-gray-950 min-h-screen">
        <div className="h-40 bg-gray-200 dark:bg-gray-800 rounded-xl animate-pulse mb-6"></div>
        <div className="h-96 bg-gray-200 dark:bg-gray-800 rounded-xl animate-pulse"></div>
      </div>
    );
  }

  if (!quizResult) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white p-8">
        <div className="text-center py-16">
          <Trophy className="w-16 h-16 text-gray-400 dark:text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Quiz Report Not Found</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-6">We couldn't find the report you're looking for.</p>
          <Link to={createPageUrl("history")}>
            <Button variant="outline" className="border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to History
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 p-4 md:p-8 text-gray-900 dark:text-white transition-colors duration-300">
      <div className="max-w-4xl mx-auto space-y-6">
        <Link to={createPageUrl("history")}>
          <Button variant="outline" className="border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Quiz History
          </Button>
        </Link>

        {/* Main Report Card */}
        <Card className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800 transition-colors duration-300">
          <CardHeader className="text-center">
            <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
              <Trophy className="w-10 h-10 text-white" />
            </div>
            <CardTitle className="text-2xl text-gray-900 dark:text-white">Quiz Report</CardTitle>
            <p className="text-gray-500 dark:text-gray-400">
              {subjects[quizResult.subject]?.name} - {format(new Date(quizResult.created_date), "MMMM d, yyyy")}
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className="text-4xl font-bold mb-2 text-gray-900 dark:text-white">
                {quizResult.score.toFixed(1)}%
              </div>
              <p className="text-gray-500 dark:text-gray-400">
                {quizResult.correct_answers} out of {quizResult.total_questions} correct
              </p>
            </div>

            {quizResult.ai_feedback && (
              <div className="bg-gray-100 dark:bg-gray-800/50 rounded-xl p-4 border border-gray-200 dark:border-gray-700/50 transition-colors duration-300">
                <h3 className="font-semibold mb-2 flex items-center gap-2 text-gray-900 dark:text-white">
                  <Brain className="w-5 h-5 text-purple-500 dark:text-purple-400" />
                  AI Feedback
                </h3>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-wrap">{quizResult.ai_feedback}</p>
              </div>
            )}

            {quizResult.weak_topics && quizResult.weak_topics.length > 0 && (
              <div className="bg-red-50 dark:bg-red-900/20 rounded-xl p-4 border border-red-200 dark:border-red-800/50 transition-colors duration-300">
                <h3 className="font-semibold mb-3 text-red-800 dark:text-red-300">Areas to Focus On</h3>
                <div className="flex flex-wrap gap-2">
                  {quizResult.weak_topics.map((topic, index) => (
                    <Badge key={index} className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">
                      {topic}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Enhanced Detailed Solutions */}
        <Card className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800 transition-colors duration-300">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-gray-900 dark:text-white">
              <BookOpen className="w-5 h-5 text-blue-500 dark:text-blue-400" />
              Detailed Solutions & Analysis
            </CardTitle>
            <p className="text-gray-500 dark:text-gray-400">Review all questions with comprehensive explanations</p>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {quizResult.questions_data.map((question, index) => {
                const userAnswer = question.user_answer;
                const isCorrect = userAnswer === question.correct_answer;
                
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6 border-l-4 transition-colors duration-300"
                    style={{ borderColor: isCorrect ? '#22c55e' : '#ef4444' }}
                  >
                    <div className="flex items-start gap-4 mb-6">
                      <div className="flex-1">
                        <h3 className="font-medium mb-3 leading-relaxed text-lg text-gray-900 dark:text-white">
                          <span className="font-bold mr-3 text-purple-600 dark:text-purple-400">Q{index + 1}.</span>
                          {question.question}
                        </h3>
                        
                        {/* Learning Objective */}
                        {question.learning_objective && (
                          <div className="mb-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800/50 transition-colors duration-300">
                            <div className="text-xs font-medium text-blue-800 dark:text-blue-300 mb-1">LEARNING OBJECTIVE</div>
                            <div className="text-sm text-blue-700 dark:text-blue-200">{question.learning_objective}</div>
                          </div>
                        )}

                        {/* Tags */}
                        {question.tags && question.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1 mb-3">
                            {question.tags.map((tag, tagIndex) => (
                              <Badge key={tagIndex} variant="outline" className="text-xs border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                        
                        {question.source?.url && (
                          <a href={question.source.url} target="_blank" rel="noopener noreferrer" className="text-xs text-gray-400 hover:text-purple-500 dark:hover:text-purple-400 transition-colors flex items-center gap-1">
                            <LinkIcon className="w-3 h-3" />
                            📚 Source: {question.source.title || 'Reference'}
                          </a>
                        )}
                      </div>
                      <div className={`flex items-center gap-2 font-medium text-sm ${
                        isCorrect ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                      }`}>
                        {isCorrect ? <CheckCircle className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
                        <span className="font-bold">{isCorrect ? 'CORRECT' : 'INCORRECT'}</span>
                      </div>
                    </div>

                    <div className="space-y-3 mb-6">
                      {question.options.map((option, optionIndex) => {
                        const isUserChoice = userAnswer === optionIndex;
                        const isCorrectChoice = question.correct_answer === optionIndex;
                        let variant = 'outline';
                        if (isCorrectChoice) variant = 'correct';
                        else if (isUserChoice && !isCorrectChoice) variant = 'incorrect';
                        
                        return (
                           <div
                              key={optionIndex}
                              className={`p-4 rounded-lg border-2 text-sm flex items-center gap-3 transition-colors duration-300
                                ${variant === 'correct' ? 'bg-green-50 dark:bg-green-900/30 border-green-500 text-green-800 dark:text-green-300' : ''}
                                ${variant === 'incorrect' ? 'bg-red-50 dark:bg-red-900/30 border-red-500 text-red-800 dark:text-red-300' : ''}
                                ${variant === 'outline' ? 'bg-gray-100 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600/50 text-gray-700 dark:text-gray-300' : ''}
                              `}
                            >
                              <span className="font-bold text-lg">
                                {String.fromCharCode(65 + optionIndex)}.
                              </span>
                              <span className="flex-1">{option}</span>
                              <div className="flex items-center gap-2">
                                {isCorrectChoice && <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400" />}
                                {isUserChoice && (<Badge variant="secondary" className="text-xs bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300">{isCorrectChoice ? 'Your Answer ✓' : 'Your Answer ✗'}</Badge>)}
                              </div>
                            </div>
                        );
                      })}
                    </div>

                    {question.explanation && (
                      <div className="bg-gradient-to-r from-gray-100 to-gray-50 dark:from-gray-700/50 dark:to-gray-800/50 rounded-lg p-6 border border-gray-200 dark:border-gray-700/50 transition-colors duration-300">
                        <h4 className="font-bold text-lg mb-4 flex items-center gap-2 text-purple-600 dark:text-purple-400">
                          <Lightbulb className="w-5 h-5 text-yellow-500" />
                          Comprehensive Explanation
                        </h4>
                        <div className="text-gray-700 dark:text-gray-300 leading-relaxed whitespace-pre-wrap">
                          {question.explanation}
                        </div>
                        
                        {/* Difficulty Justification */}
                        {question.difficulty_justification && (
                          <div className="mt-4 p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800/50 transition-colors duration-300">
                            <div className="text-xs font-medium text-purple-800 dark:text-purple-300 mb-1">DIFFICULTY ANALYSIS</div>
                            <div className="text-sm text-purple-700 dark:text-purple-200">{question.difficulty_justification}</div>
                          </div>
                        )}
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}