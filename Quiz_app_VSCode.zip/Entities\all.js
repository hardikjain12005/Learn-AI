// Mock entity classes with localStorage persistence for development
class MockEntity {
  constructor(data = {}) {
    Object.assign(this, data);
    if (!this.id) {
      this.id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    }
    if (!this.created_date) {
      this.created_date = new Date().toISOString();
    }
    if (!this.created_by) {
      // Set created_by based on current user or default to guest
      const currentUser = localStorage.getItem('current_user');
      if (currentUser) {
        const user = JSON.parse(currentUser);
        this.created_by = user.email;
      } else {
        this.created_by = 'guest@example.com'; // Default for guest users
      }
    }
  }

  static getStorageKey() {
    return `mock_${this.name.toLowerCase()}`;
  }

  static getAllData() {
    const key = this.getStorageKey();
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  }

  static saveAllData(data) {
    const key = this.getStorageKey();
    localStorage.setItem(key, JSON.stringify(data));
  }

  static async filter(criteria = {}, sortBy = null, limit = null) {
    let data = this.getAllData();
    
    // Apply filters
    if (Object.keys(criteria).length > 0) {
      data = data.filter(item => {
        return Object.entries(criteria).every(([key, value]) => {
          return item[key] === value;
        });
      });
    }

    // Apply sorting
    if (sortBy) {
      const isDescending = sortBy.startsWith('-');
      const sortField = isDescending ? sortBy.substring(1) : sortBy;
      
      data.sort((a, b) => {
        const aVal = a[sortField];
        const bVal = b[sortField];
        
        if (aVal < bVal) return isDescending ? 1 : -1;
        if (aVal > bVal) return isDescending ? -1 : 1;
        return 0;
      });
    }

    // Apply limit
    if (limit && limit > 0) {
      data = data.slice(0, limit);
    }

    return data.map(item => new this(item));
  }

  static async create(data) {
    const instance = new this(data);
    const allData = this.getAllData();
    allData.push(instance);
    this.saveAllData(allData);
    return instance;
  }

  static async findById(id) {
    const allData = this.getAllData();
    const item = allData.find(item => item.id === id);
    return item ? new this(item) : null;
  }

  async save() {
    const allData = this.constructor.getAllData();
    const existingIndex = allData.findIndex(item => item.id === this.id);
    
    if (existingIndex >= 0) {
      allData[existingIndex] = { ...this };
    } else {
      allData.push({ ...this });
    }
    
    this.constructor.saveAllData(allData);
    return this;
  }

  async delete() {
    const allData = this.constructor.getAllData();
    const filteredData = allData.filter(item => item.id !== this.id);
    this.constructor.saveAllData(filteredData);
    return true;
  }

  static async update(id, data) {
    const allData = this.getAllData();
    const existingIndex = allData.findIndex(item => item.id === id);
    
    if (existingIndex >= 0) {
      allData[existingIndex] = { ...allData[existingIndex], ...data, id };
      this.saveAllData(allData);
      return new this(allData[existingIndex]);
    }
    
    return null;
  }
}

export class QuizResult extends MockEntity {
  static name = 'QuizResult';
}

export class UserProgress extends MockEntity {
  static name = 'UserProgress';
}

export class ChatMessage extends MockEntity {
  static name = 'ChatMessage';
}
