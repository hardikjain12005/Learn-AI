import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { QuizResult } from "@/entities/all";
import { User } from "@/entities/User";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { History, BookOpen, Trophy, ChevronRight } from "lucide-react";

const subjects = {
  dsa_c: { name: "DSA (C)", color: "from-blue-500 to-cyan-500", icon: "🔢" },
  oops_cpp: { name: "OOPS (C++)", color: "from-purple-500 to-pink-500", icon: "🎯" },
  software_engineering: { name: "Software Engineering", color: "from-green-500 to-emerald-500", icon: "⚙️" },
  c_language: { name: "C Language", color: "from-orange-500 to-red-500", icon: "💻" },
  digital_electronics: { name: "Digital Electronics", color: "from-indigo-500 to-purple-500", icon: "⚡" },
  java: { name: "JAVA", color: "from-red-500 to-pink-500", icon: "☕" },
  python: { name: "Python", color: "from-yellow-500 to-orange-500", icon: "🐍" }
};

export default function HistoryPage() {
  const [quizHistory, setQuizHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadHistory = async () => {
      try {
        const user = await User.me();
        const results = await QuizResult.filter({ created_by: user.email }, "-created_date");
        setQuizHistory(results);
      } catch (error) {
        console.error("Error loading quiz history:", error);
      }
      setIsLoading(false);
    };

    loadHistory();
  }, []);

  if (isLoading) {
    return (
      <div className="p-8 space-y-4">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-24 bg-gray-800 rounded-xl animate-pulse"></div>
        ))}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <History className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-white">
              Quiz History
            </h1>
          </div>
          <p className="text-gray-400 text-lg">Review your past performance and learn from your results.</p>
        </motion.div>

        {quizHistory.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <BookOpen className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No Quizzes Taken Yet</h3>
            <p className="text-gray-400 mb-6">Your quiz history will appear here once you complete a quiz.</p>
            <Link to={createPageUrl("quiz")}>
              <Button className="bg-gradient-to-r from-purple-500 to-pink-500">
                Take Your First Quiz
              </Button>
            </Link>
          </motion.div>
        ) : (
          <div className="space-y-4">
            {quizHistory.map((result, index) => (
              <motion.div
                key={result.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Link to={createPageUrl(`report?id=${result.id}`)}>
                  <Card className="bg-gray-900 border-gray-800 hover:border-purple-500 transition-all duration-300">
                    <CardContent className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 bg-gradient-to-r ${subjects[result.subject]?.color} rounded-lg flex items-center justify-center text-xl`}>
                          {subjects[result.subject]?.icon}
                        </div>
                        <div>
                          <h3 className="text-white font-bold">{subjects[result.subject]?.name}</h3>
                          <p className="text-gray-400 text-sm">
                            {format(new Date(result.created_date), "MMM d, yyyy")}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge className={`${
                          result.score >= 80 ? 'bg-green-900 text-green-300' :
                          result.score >= 60 ? 'bg-yellow-900 text-yellow-300' :
                          'bg-red-900 text-red-300'
                        } flex items-center gap-1`}>
                          <Trophy className="w-3 h-3" />
                          {result.score.toFixed(0)}%
                        </Badge>
                        <ChevronRight className="w-5 h-5 text-gray-500" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}