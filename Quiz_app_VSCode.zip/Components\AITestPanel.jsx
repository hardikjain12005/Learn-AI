import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { InvokeLLM } from '@/integrations/Core';

export default function AITestPanel() {
  const [testResults, setTestResults] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  const testQuestionGeneration = async () => {
    setIsLoading(true);
    try {
      console.log('Testing question generation...');
      const response = await InvokeLLM({
        prompt: 'Generate EXACTLY 3 highly sophisticated multiple-choice questions for "DSA (C)" at medium difficulty level.',
        response_json_schema: {
          type: "object",
          properties: {
            questions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  question: { type: "string" },
                  options: { type: "array", items: { type: "string" } },
                  correct_answer: { type: "number" },
                  explanation: { type: "string" }
                }
              }
            }
          }
        }
      });
      
      setTestResults(prev => ({
        ...prev,
        questions: {
          success: !!response?.questions,
          count: response?.questions?.length || 0,
          data: response
        }
      }));
    } catch (error) {
      setTestResults(prev => ({
        ...prev,
        questions: { success: false, error: error.message }
      }));
    }
    setIsLoading(false);
  };

  const testChatResponse = async () => {
    setIsLoading(true);
    try {
      console.log('Testing chat response...');
      const response = await InvokeLLM({
        prompt: 'Explain binary search algorithm'
      });
      
      setTestResults(prev => ({
        ...prev,
        chat: {
          success: !!response,
          data: response
        }
      }));
    } catch (error) {
      setTestResults(prev => ({
        ...prev,
        chat: { success: false, error: error.message }
      }));
    }
    setIsLoading(false);
  };

  const testTaskGeneration = async () => {
    setIsLoading(true);
    try {
      console.log('Testing task generation...');
      const response = await InvokeLLM({
        prompt: 'Generate tasks based on quiz performance',
        response_json_schema: {
          type: "object",
          properties: {
            tasks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  task: { type: "string" },
                  reason: { type: "string" },
                  subject: { type: "string" }
                }
              }
            }
          }
        }
      });
      
      setTestResults(prev => ({
        ...prev,
        tasks: {
          success: !!response?.tasks,
          count: response?.tasks?.length || 0,
          data: response
        }
      }));
    } catch (error) {
      setTestResults(prev => ({
        ...prev,
        tasks: { success: false, error: error.message }
      }));
    }
    setIsLoading(false);
  };

  return (
    <Card className="bg-gray-900 border-gray-700 text-white">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          🧪 AI System Test Panel
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button 
            onClick={testQuestionGeneration} 
            disabled={isLoading}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isLoading ? '⏳ Testing...' : '📝 Test Questions'}
          </Button>
          
          <Button 
            onClick={testChatResponse} 
            disabled={isLoading}
            className="bg-green-600 hover:bg-green-700"
          >
            {isLoading ? '⏳ Testing...' : '💬 Test Chat'}
          </Button>
          
          <Button 
            onClick={testTaskGeneration} 
            disabled={isLoading}
            className="bg-purple-600 hover:bg-purple-700"
          >
            {isLoading ? '⏳ Testing...' : '🎯 Test Tasks'}
          </Button>
        </div>

        <div className="space-y-3">
          {testResults.questions && (
            <div className={`p-3 rounded border ${testResults.questions.success ? 'border-green-600 bg-green-900/20' : 'border-red-600 bg-red-900/20'}`}>
              <div className="font-semibold">
                📝 Question Generation: {testResults.questions.success ? '✅ SUCCESS' : '❌ FAILED'}
              </div>
              {testResults.questions.success && (
                <div className="text-sm mt-1">Generated {testResults.questions.count} questions</div>
              )}
              {testResults.questions.error && (
                <div className="text-sm mt-1 text-red-400">Error: {testResults.questions.error}</div>
              )}
            </div>
          )}

          {testResults.chat && (
            <div className={`p-3 rounded border ${testResults.chat.success ? 'border-green-600 bg-green-900/20' : 'border-red-600 bg-red-900/20'}`}>
              <div className="font-semibold">
                💬 Chat Response: {testResults.chat.success ? '✅ SUCCESS' : '❌ FAILED'}
              </div>
              {testResults.chat.success && (
                <div className="text-sm mt-1">Response: "{typeof testResults.chat.data === 'string' ? testResults.chat.data.substring(0, 100) + '...' : 'Generated response'}"</div>
              )}
              {testResults.chat.error && (
                <div className="text-sm mt-1 text-red-400">Error: {testResults.chat.error}</div>
              )}
            </div>
          )}

          {testResults.tasks && (
            <div className={`p-3 rounded border ${testResults.tasks.success ? 'border-green-600 bg-green-900/20' : 'border-red-600 bg-red-900/20'}`}>
              <div className="font-semibold">
                🎯 Task Generation: {testResults.tasks.success ? '✅ SUCCESS' : '❌ FAILED'}
              </div>
              {testResults.tasks.success && (
                <div className="text-sm mt-1">Generated {testResults.tasks.count} priority tasks</div>
              )}
              {testResults.tasks.error && (
                <div className="text-sm mt-1 text-red-400">Error: {testResults.tasks.error}</div>
              )}
            </div>
          )}
        </div>

        <div className="text-xs text-gray-400 bg-gray-800 p-2 rounded">
          <strong>Test Instructions:</strong> Click each button to test different AI functions. 
          Check browser console for detailed logs. All functions should return ✅ SUCCESS.
        </div>
      </CardContent>
    </Card>
  );
}
