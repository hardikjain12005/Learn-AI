
import React, { useState, useEffect, useRef, useCallback } from "react";
import { ChatMessage, QuizResult } from "@/entities/all";
import { User } from "@/entities/User";
import { InvokeLLM } from "@/integrations/Core";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Brain, 
  Send, 
  BookOpen, 
  Code, 
  Lightbulb,
  MessageCircle,
  Sparkles,
  User as UserIcon,
  Zap,
  Target,
  Bug,
  PlayCircle,
  FileText,
  TrendingUp
} from "lucide-react";

const subjects = {
  dsa_c: { name: "DSA (C)", icon: "🔢" },
  oops_cpp: { name: "OOPS (C++)", icon: "🎯" },
  software_engineering: { name: "Software Engineering", icon: "⚙️" },
  c_language: { name: "C Language", icon: "💻" },
  digital_electronics: { name: "Digital Electronics", icon: "⚡" },
  java: { name: "JAVA", icon: "☕" },
  python: { name: "Python", icon: "🐍" }
};

const advancedFeatures = [
  { 
    id: 'explain_simple', 
    label: 'Explain Simply', 
    icon: Lightbulb, 
    prompt: 'Explain this concept in simple terms that a beginner would understand'
  },
  { 
    id: 'explain_advanced', 
    label: 'Advanced Theory', 
    icon: Brain, 
    prompt: 'Provide an advanced, detailed explanation with underlying theory and mathematical foundations'
  },
  { 
    id: 'generate_practice', 
    label: 'Practice Problems', 
    icon: Target, 
    prompt: 'Generate 3 practice problems related to this topic with varying difficulty levels'
  },
  { 
    id: 'code_review', 
    label: 'Code Analysis', 
    icon: Code, 
    prompt: 'Analyze the code I provide for bugs, performance improvements, and best practices'
  },
  { 
    id: 'debug_challenge', 
    label: 'Debug Challenge', 
    icon: Bug, 
    prompt: 'Create a code debugging challenge with intentional bugs for me to find and fix'
  },
  { 
    id: 'output_prediction', 
    label: 'Predict Output', 
    icon: PlayCircle, 
    prompt: 'Give me a code snippet and ask me to predict its output, then explain the result'
  }
];

export default function Tutor() {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [selectedSubject, setSelectedSubject] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [userQuizData, setUserQuizData] = useState([]);
  const [proactiveInsights, setProactiveInsights] = useState([]);
  const [explanationLevel, setExplanationLevel] = useState('balanced');
  const messagesEndRef = useRef(null);
  const chatContainerRef = useRef(null);

  const generateProactiveInsights = useCallback(async (quizData) => {
    try {
      const analyticsPrompt = `Analyze this student's quiz performance data and generate proactive learning insights:

      Quiz History: ${JSON.stringify(quizData.map(q => ({
        subject: q.subject,
        difficulty: q.difficulty,
        score: q.score,
        weak_topics: q.weak_topics || [],
        date: q.created_date
      })))}

      Based on this data, provide:
      1. Patterns in performance (strengths/weaknesses)
      2. Specific topics that need attention
      3. Recommended next steps
      4. Personalized study suggestions
      
      Return as JSON with this structure:
      {
        "insights": [
          {
            "type": "strength|weakness|recommendation",
            "message": "Human-readable insight",
            "subject": "relevant subject",
            "action": "specific action to take"
          }
        ]
      }`;

      const response = await InvokeLLM({
        prompt: analyticsPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            insights: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string" },
                  message: { type: "string" },
                  subject: { type: "string" },
                  action: { type: "string" }
                }
              }
            }
          }
        }
      });

      setProactiveInsights(response.insights || []);
    } catch (error) {
      console.error("Error generating insights:", error);
    }
  }, []);

  const loadChatHistory = useCallback(async () => {
    try {
      const user = await User.me();
      const history = await ChatMessage.filter({ created_by: user.email }, '-created_date', 50);
      setMessages(history.reverse());
    } catch (error) {
      console.error("Error loading chat:", error);
    }
  }, []);

  const loadUserAnalytics = useCallback(async () => {
    try {
      const user = await User.me();
      const quizResults = await QuizResult.filter({ created_by: user.email }, '-created_date', 10);
      setUserQuizData(quizResults);
      
      if (quizResults.length > 0) {
        generateProactiveInsights(quizResults);
      }
    } catch (error) {
      console.error("Error loading analytics:", error);
    }
  }, [generateProactiveInsights]);

  useEffect(() => {
    loadChatHistory();
    loadUserAnalytics();
  }, [loadChatHistory, loadUserAnalytics]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (message = inputMessage, specialMode = null) => {
    if (!message.trim()) return;

    const userMessage = {
      message: message.trim(),
      role: "user",
      subject_context: selectedSubject,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setIsLoading(true);

    try {
      // Save user message
      await ChatMessage.create(userMessage);

      // Prepare enhanced context for AI
      const recentMessages = [...messages, userMessage].slice(-20);
      const contextMessages = recentMessages.map(m => `${m.role}: ${m.message}`).join('\n');
      
      // Enhanced quiz context with patterns
      const quizContext = userQuizData.slice(0, 5).map(q => ({
        subject: q.subject,
        score: q.score,
        weak_topics: q.weak_topics,
        difficulty: q.difficulty,
        date: q.created_date
      }));

      // Detect if user is asking for code analysis
      const isCodeQuery = /```|function|class|def |#include|import |public static|console\.log|print\(/.test(message);
      
      let enhancedPrompt = `You are an advanced AI tutor with deep expertise in computer science and engineering. You are highly intelligent, proactive, and adaptive.

      STUDENT CONTEXT:
      - Current subject focus: ${selectedSubject ? subjects[selectedSubject]?.name : 'General'}
      - Explanation preference: ${explanationLevel}
      - Recent quiz performance: ${JSON.stringify(quizContext)}
      - Learning insights: ${JSON.stringify(proactiveInsights)}

      ADVANCED CAPABILITIES:
      ${isCodeQuery ? `
      🔍 CODE ANALYSIS MODE DETECTED:
      - Perform comprehensive code review including: syntax errors, logical bugs, performance issues, security vulnerabilities
      - Suggest improvements for readability, maintainability, and best practices
      - Provide refactored code examples when applicable
      - Explain complex algorithms step-by-step with time/space complexity analysis
      ` : ''}

      CONVERSATION HISTORY (last 20 messages):
      ${contextMessages}

      INSTRUCTIONS:
      1. Be proactive: If you notice patterns in their quiz performance, offer targeted help
      2. Adapt explanation complexity based on their preference: ${explanationLevel}
      3. Use mathematical notation with LaTeX when needed: $formula$ or $$complex formula$$
      4. For code: provide syntax highlighting, explain algorithms, and suggest optimizations
      6. Generate practice problems when requested
      5. Be encouraging but honest about areas needing improvement

      ${specialMode ? `SPECIAL MODE: ${specialMode}` : ''}

      Student message: ${message}`;

      const response = await InvokeLLM({
        prompt: enhancedPrompt,
        add_context_from_internet: true
      });

      const assistantMessage = {
        message: response,
        role: "assistant",
        subject_context: selectedSubject,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, assistantMessage]);
      await ChatMessage.create(assistantMessage);

    } catch (error) {
      console.error("Error sending message:", error);
      setMessages(prev => [...prev, {
        message: "I'm having trouble connecting right now. Please try again in a moment.",
        role: "assistant",
        timestamp: new Date().toISOString()
      }]);
    }

    setIsLoading(false);
  };

  const handleAdvancedFeature = (feature) => {
    const prompt = `${feature.prompt}. ${selectedSubject ? `Focus on ${subjects[selectedSubject].name}` : ''}`;
    sendMessage(prompt, feature.label);
  };

  const clearChat = () => {
    setMessages([]);
    setSelectedSubject(null);
  };

  const generatePracticeProblems = async () => {
    const subject = selectedSubject || 'general programming';
    const prompt = `Generate 3 diverse practice problems for ${subjects[subject]?.name || subject}:
    
    1. A coding challenge (medium difficulty)
    2. A debugging challenge with buggy code to fix
    3. An output prediction problem
    
    Base the difficulty on my recent performance: ${JSON.stringify(userQuizData.slice(0, 3))}
    
    Format each problem clearly with explanations and solutions.`;
    
    sendMessage(prompt, 'Practice Problem Generator');
  };

  return (
    <div className="min-h-screen bg-gray-950 p-2 sm:p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-4 md:mb-8"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-white">
              Advanced AI Tutor
            </h1>
            <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
              <Zap className="w-3 h-3 mr-1" />
              Intelligent
            </Badge>
          </div>
          <p className="text-gray-400 text-lg">Proactive learning companion with advanced AI capabilities</p>
        </motion.div>

        <div className="grid grid-cols-1 xl:grid-cols-5 gap-4 lg:gap-6 min-h-0">
          {/* Enhanced Sidebar - Hidden on mobile, shown on xl+ screens */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="hidden xl:block xl:col-span-1 space-y-4 overflow-y-auto max-h-screen"
          >
            {/* Subject Selection */}
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white text-lg">Subject Focus</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button
                    variant={!selectedSubject ? "default" : "outline"}
                    className={`w-full justify-start ${!selectedSubject ? 'bg-gradient-to-r from-purple-500 to-pink-500' : 'border-gray-600 text-gray-300 hover:bg-gray-800'}`}
                    onClick={() => setSelectedSubject(null)}
                  >
                    <BookOpen className="w-4 h-4 mr-2" />
                    General Help
                  </Button>
                  {Object.entries(subjects).map(([key, subject]) => (
                    <Button
                      key={key}
                      variant={selectedSubject === key ? "default" : "outline"}
                      className={`w-full justify-start text-sm min-h-[44px] p-3 ${selectedSubject === key ? 'bg-gradient-to-r from-purple-500 to-pink-500' : 'border-gray-600 text-gray-300 hover:bg-gray-800'}`}
                      onClick={() => setSelectedSubject(key)}
                    >
                      <span className="mr-2 flex-shrink-0">{subject.icon}</span>
                      <span className="break-words text-left leading-tight">{subject.name}</span>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Explanation Level */}
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white text-sm">Explanation Style</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[
                    { key: 'simple', label: 'Simple', icon: '🟢' },
                    { key: 'balanced', label: 'Balanced', icon: '🟡' },
                    { key: 'advanced', label: 'Advanced', icon: '🔴' }
                  ].map(level => (
                    <Button
                      key={level.key}
                      variant={explanationLevel === level.key ? "default" : "outline"}
                      className={`w-full justify-start text-sm ${explanationLevel === level.key ? 'bg-gradient-to-r from-blue-500 to-cyan-500' : 'border-gray-600 text-gray-300 hover:bg-gray-800'}`}
                      onClick={() => setExplanationLevel(level.key)}
                    >
                      <span className="mr-2">{level.icon}</span>
                      {level.label}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Proactive Insights */}
            {proactiveInsights.length > 0 && (
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-green-400 flex-shrink-0" />
                    <span className="truncate">AI Insights</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-3">
                  <div className="space-y-3">
                    {proactiveInsights.slice(0, 3).map((insight, index) => (
                      <div key={index} className="p-3 bg-gray-800 rounded-lg text-xs space-y-2">
                        <div className={`font-medium text-xs uppercase tracking-wider ${
                          insight.type === 'strength' ? 'text-green-400' :
                          insight.type === 'weakness' ? 'text-red-400' : 'text-blue-400'
                        }`}>
                          {insight.type}
                        </div>
                        <div className="text-gray-300 text-xs leading-relaxed break-words">
                          {insight.message}
                        </div>
                        {insight.action && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="mt-2 p-2 h-auto text-xs text-purple-400 hover:text-purple-300 hover:bg-gray-700 w-full justify-start"
                            onClick={() => sendMessage(insight.action)}
                          >
                            <span className="truncate">{insight.action}</span>
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </motion.div>

          {/* Main Chat Interface */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="col-span-1 xl:col-span-3 min-h-0"
          >
            <Card className="bg-gray-900 border-gray-800 h-[500px] sm:h-[600px] lg:h-[700px] flex flex-col">
              <CardHeader className="border-b border-gray-800">
                <div className="flex justify-between items-start mb-3">
                  <CardTitle className="text-white flex items-center gap-2">
                    <MessageCircle className="w-5 h-5 text-purple-400" />
                    Advanced AI Chat
                  </CardTitle>
                  {messages.length > 0 && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={clearChat}
                      className="border-gray-600 text-gray-300 hover:bg-gray-800"
                    >
                      Clear Chat
                    </Button>
                  )}
                </div>
                
                {/* Mobile subject selector */}
                <div className="xl:hidden mb-3">
                  <div className="flex flex-wrap gap-2 mb-2">
                    <Button
                      variant={!selectedSubject ? "default" : "outline"}
                      size="sm"
                      className={`${!selectedSubject ? 'bg-gradient-to-r from-purple-500 to-pink-500' : 'border-gray-600 text-gray-300'}`}
                      onClick={() => setSelectedSubject(null)}
                    >
                      <BookOpen className="w-3 h-3 mr-1" />
                      General
                    </Button>
                    {Object.entries(subjects).slice(0, 4).map(([key, subject]) => (
                      <Button
                        key={key}
                        variant={selectedSubject === key ? "default" : "outline"}
                        size="sm"
                        className={`text-xs ${selectedSubject === key ? 'bg-gradient-to-r from-purple-500 to-pink-500' : 'border-gray-600 text-gray-300'}`}
                        onClick={() => setSelectedSubject(key)}
                      >
                        {subject.icon} {subject.name.split(' ')[0]}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {selectedSubject && (
                    <Badge className="bg-purple-900 text-purple-300">
                      {subjects[selectedSubject].icon} {subjects[selectedSubject].name}
                    </Badge>
                  )}
                  <Badge className="bg-blue-900 text-blue-300">
                    {explanationLevel} explanations
                  </Badge>
                </div>
              </CardHeader>

              {/* Messages Area */}
              <CardContent 
                ref={chatContainerRef}
                className="flex-1 overflow-y-auto p-4 space-y-4"
              >
                <AnimatePresence>
                  {messages.length === 0 ? (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="text-center py-12"
                    >
                      <Brain className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-white mb-2">AI Tutor Ready!</h3>
                      <p className="text-gray-400 mb-4">I can help with code analysis, generate practice problems, and provide personalized explanations</p>
                      {proactiveInsights.length > 0 && (
                        <div className="text-sm text-purple-400">
                          💡 I have {proactiveInsights.length} insights based on your quiz history
                        </div>
                      )}
                    </motion.div>
                  ) : (
                    messages.map((msg, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                      >
                        <div className={`max-w-[85%] p-4 rounded-2xl ${
                          msg.role === "user" 
                            ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white" 
                            : "bg-gray-800 text-gray-300 border border-gray-700"
                        }`}>
                          <div className="flex items-start gap-2 mb-2">
                            {msg.role === "user" ? (
                              <UserIcon className="w-4 h-4 mt-0.5" />
                            ) : (
                              <Sparkles className="w-4 h-4 mt-0.5 text-purple-400" />
                            )}
                            <span className="text-sm font-medium">
                              {msg.role === "user" ? "You" : "AI Tutor"}
                            </span>
                          </div>
                          <div className="whitespace-pre-wrap leading-relaxed text-sm">
                            {msg.message}
                          </div>
                        </div>
                      </motion.div>
                    ))
                  )}
                </AnimatePresence>
                
                {isLoading && (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex justify-start"
                  >
                    <div className="bg-gray-800 p-4 rounded-2xl border border-gray-700">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
                        <span className="text-gray-300">AI analyzing and generating response...</span>
                      </div>
                    </div>
                  </motion.div>
                )}
                
                <div ref={messagesEndRef} />
              </CardContent>

              {/* Enhanced Input Area */}
              <div className="border-t border-gray-800 p-4">
                <div className="flex gap-3 mb-3">
                  <Textarea
                    placeholder="Ask anything, paste code for analysis, or request practice problems..."
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        sendMessage();
                      }
                    }}
                    className="flex-1 bg-gray-800 border-gray-700 text-white placeholder-gray-400 resize-none"
                    rows={3}
                  />
                  <div className="flex flex-col gap-2">
                    <Button
                      onClick={() => sendMessage()}
                      disabled={!inputMessage.trim() || isLoading}
                      className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      onClick={generatePracticeProblems}
                      className="border-gray-600 text-gray-300 hover:bg-gray-800"
                      title="Generate Practice Problems"
                    >
                      <Target className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Quick Action Buttons */}
                <div className="flex flex-wrap gap-2">
                  {advancedFeatures.slice(0, 4).map((feature, index) => (
                    <Button
                      key={index}
                      variant="ghost"
                      size="sm"
                      onClick={() => handleAdvancedFeature(feature)}
                      className="text-gray-400 hover:text-purple-400 hover:bg-gray-800 text-xs"
                    >
                      <feature.icon className="w-3 h-3 mr-1" />
                      {feature.label}
                    </Button>
                  ))}
                </div>
              </div>
            </Card>
          </motion.div>

          {/* Advanced Features Panel - Hidden on mobile, shown on xl+ screens */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="hidden xl:block xl:col-span-1 overflow-y-auto max-h-screen"
          >
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white text-lg">Advanced Features</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {advancedFeatures.map((feature) => (
                    <Button
                      key={feature.id}
                      variant="outline"
                      className="w-full justify-start text-sm border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-purple-400 min-h-[44px] p-3"
                      onClick={() => handleAdvancedFeature(feature)}
                    >
                      <feature.icon className="w-4 h-4 mr-2 flex-shrink-0" />
                      <span className="break-words text-left leading-tight">{feature.label}</span>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
