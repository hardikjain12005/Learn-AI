
import React, { useState, useEffect, useCallback } from "react";
import { QuizResult, UserProgress } from "@/entities/all";
import { User } from "@/entities/User";
import { InvokeLLM } from "@/integrations/Core";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { motion, AnimatePresence } from "framer-motion";
import { createPageUrl } from "@/utils";
import { useToast } from "@/components/ui/use-toast";
import {
  BookOpen,
  Clock,
  CheckCircle,
  XCircle,
  ArrowLeft,
  ArrowRight,
  Trophy,
  Target,
  Brain,
  RefreshCw,
  Lightbulb,
  AlertTriangle,
  LogIn
} from "lucide-react";

const subjects = {
  dsa_c: { name: "DSA (C)", color: "from-blue-500 to-cyan-500", icon: "🔢" },
  oops_cpp: { name: "OOPS (C++)", color: "from-purple-500 to-pink-500", icon: "🎯" },
  software_engineering: { name: "Software Engineering", color: "from-green-500 to-emerald-500", icon: "⚙️" },
  c_language: { name: "C Language", color: "from-orange-500 to-red-500", icon: "💻" },
  digital_electronics: { name: "Digital Electronics", color: "from-indigo-500 to-purple-500", icon: "⚡" },
  java: { name: "JAVA", color: "from-red-500 to-pink-500", icon: "☕" },
  python: { name: "Python", color: "from-yellow-500 to-orange-500", icon: "🐍" }
};

const difficulties = [
  { value: "easy", label: "Easy", color: "text-green-400" },
  { value: "medium", label: "Medium", color: "text-yellow-400" },
  { value: "hard", label: "Hard", color: "text-red-400" }
];

const GUEST_QUIZ_LIMIT = 3;

export default function Quiz() {
  const [step, setStep] = useState("subject"); // subject, config, quiz, results, guest_limit
  const [selectedSubject, setSelectedSubject] = useState(null);
  const [difficulty, setDifficulty] = useState("medium");
  const [questionCount, setQuestionCount] = useState(10);
  const [timeLimit, setTimeLimit] = useState(10);
  const [questions, setQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [userAnswers, setUserAnswers] = useState([]);
  const [timeLeft, setTimeLeft] = useState(600);
  const [isLoading, setIsLoading] = useState(false);
  const [quizResults, setQuizResults] = useState(null);
  const [isGuest, setIsGuest] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const checkUserStatus = async () => {
      try {
        await User.me();
        setIsGuest(false);
      } catch (error) {
        setIsGuest(true);
        const guestQuizzes = parseInt(localStorage.getItem('guestQuizCount') || '0');
        if (guestQuizzes >= GUEST_QUIZ_LIMIT) {
          setStep('guest_limit');
        }
      }
    };
    checkUserStatus();
  }, []);

  const handleQuizComplete = useCallback(async () => {
    if (isGuest) {
      const guestQuizzes = parseInt(localStorage.getItem('guestQuizCount') || '0');
      localStorage.setItem('guestQuizCount', (guestQuizzes + 1).toString());
    }

    const correctAnswers = questions.reduce((count, question, index) => {
      return count + (userAnswers[index] === question.correct_answer ? 1 : 0);
    }, 0);

    const score = (questions.length === 0) ? 0 : (correctAnswers / questions.length) * 100;
    const timeTaken = (timeLimit * 60) - timeLeft;

    let aiFeedback = "Great effort! Keep practicing to improve your skills.";
    let weakTopics = [];

    if (!isGuest) {
      const incorrectQuestions = questions
        .map((q, i) => ({ ...q, userAnswer: userAnswers[i], questionIndex: i }))
        .filter(q => q.userAnswer !== q.correct_answer);

      if (incorrectQuestions.length > 0) {
        try {
          const feedbackPrompt = `Analyze this quiz performance for ${subjects[selectedSubject].name}:
          Score: ${score.toFixed(1)}%
          Incorrect questions: ${JSON.stringify(incorrectQuestions.map(q => ({question: q.question, your_answer: q.options[q.userAnswer], correct_answer: q.options[q.correct_answer]})))}

          Provide a detailed, multi-paragraph report that includes:
          1. A constructive performance summary.
          2. A clear list of weak topics identified from the incorrect answers.
          3. Specific, actionable recommendations for improvement.
          4. A motivational message to encourage the student.

          Return as JSON with a 'feedback' (string) and 'weak_topics' (array of strings) field.`;

          const feedbackResponse = await InvokeLLM({
            prompt: feedbackPrompt,
            response_json_schema: {
              type: "object", properties: { feedback: { type: "string" }, weak_topics: { type: "array", items: { type: "string" } } }
            }
          });
          aiFeedback = feedbackResponse.feedback || aiFeedback;
          weakTopics = feedbackResponse.weak_topics || [];
        } catch (error) { console.error("Error generating AI feedback:", error); }
      } else {
        aiFeedback = "Perfect score! You've mastered this topic. Consider trying a harder difficulty level.";
      }
    }

    const resultData = {
      subject: selectedSubject,
      difficulty,
      score,
      total_questions: questions.length,
      correct_answers: correctAnswers,
      time_taken: timeTaken,
      questions_data: questions.map((q, i) => ({ ...q, user_answer: userAnswers[i] })),
      weak_topics: weakTopics,
      ai_feedback: aiFeedback
    };

    if (!isGuest) {
      await QuizResult.create(resultData);
      
      const user = await User.me();
      const existingProgress = await UserProgress.filter({ subject: selectedSubject, created_by: user.email });

      if (existingProgress.length > 0) {
        const current = existingProgress[0];
        const newAvgScore = ((current.average_score * current.quizzes_taken) + score) / (current.quizzes_taken + 1);
        await UserProgress.update(current.id, {
          mastery_level: newAvgScore,
          quizzes_taken: current.quizzes_taken + 1,
          average_score: newAvgScore,
          last_quiz_date: new Date().toISOString().split('T')[0],
          weak_topics: weakTopics, // Update weak topics based on latest quiz
          recommended_difficulty: score >= 80 ? "hard" : score >= 60 ? "medium" : "easy" // Re-evaluate recommended difficulty
        });
      } else {
        await UserProgress.create({
          subject: selectedSubject,
          mastery_level: score,
          quizzes_taken: 1,
          average_score: score,
          last_quiz_date: new Date().toISOString().split('T')[0],
          weak_topics: weakTopics, // Store weak topics for new progress
          recommended_difficulty: score >= 80 ? "hard" : score >= 60 ? "medium" : "easy"
        });
      }
    }

    setQuizResults({ score, correctAnswers, total: questions.length, feedback: aiFeedback, weakTopics });
    setStep("results");
  }, [questions, userAnswers, selectedSubject, difficulty, timeLimit, timeLeft, isGuest]);

  useEffect(() => {
    let timer;
    if (step === "quiz" && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            handleQuizComplete();
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [step, timeLeft, handleQuizComplete]);

  const generateQuiz = async () => {
    setIsLoading(true);
    try {
      let effectiveDifficulty = difficulty; 
      let weakTopicsContext = "";

      if (!isGuest && selectedSubject) {
        try {
          const user = await User.me();
          const existingProgress = await UserProgress.filter({ subject: selectedSubject, created_by: user.email });

          if (existingProgress.length > 0) {
            const progress = existingProgress[0];
            if (progress.recommended_difficulty) {
              effectiveDifficulty = progress.recommended_difficulty;
            }
            if (progress.weak_topics && progress.weak_topics.length > 0) {
              weakTopicsContext = `Additionally, the user's historical data indicates weaker performance in these specific topics within ${subjects[selectedSubject].name}: ${progress.weak_topics.join(', ')}. Please prioritize generating questions that specifically target these weak areas, while still adhering to the overall subject and difficulty.`;
            }
          }
        } catch (error) {
          console.error("Error fetching user progress for AI task prioritization:", error);
        }
      }

      const prompt = `Generate EXACTLY ${questionCount} highly sophisticated multiple-choice questions for "${subjects[selectedSubject].name}" at ${effectiveDifficulty} difficulty level.

      ${weakTopicsContext}

      CRITICAL REQUIREMENTS:
      - Generate EXACTLY ${questionCount} questions, no more, no less
      - Use comprehensive search grounding from NPTEL courses, LeetCode problems, academic papers, and industry standards
      - Include questions that test: conceptual understanding, problem-solving, code analysis, and practical applications
      - Each question should challenge critical thinking, not just memorization
      - For coding questions: include algorithm complexity analysis, debugging scenarios, and output prediction
      - For theoretical questions: include mathematical proofs, system design, and real-world applications

      QUESTION DIVERSITY:
      - 40% conceptual/theoretical questions
      - 30% code analysis/debugging questions  
      - 20% problem-solving/algorithm questions
      - 10% practical application/system design questions

      Return JSON with this exact structure:
      {
        "questions": [
          {
            "question": "Detailed question text with context and requirements",
            "options": ["Option A with detailed explanation", "Option B with context", "Option C with specifics", "Option D with details"],
            "correct_answer": 0,
            "explanation": "Comprehensive explanation including: why this answer is correct, why others are wrong, underlying concepts, mathematical derivations (use LaTeX: $formula$), step-by-step reasoning, practical applications, and related concepts to explore further.",
            "source": {
              "title": "Specific source title (e.g., 'NPTEL IIT Bombay - Data Structures')",
              "url": "Direct URL to the educational resource"
            },
            "difficulty_justification": "Why this question fits the ${effectiveDifficulty} level",
            "learning_objective": "What specific skill or concept this question tests",
            "tags": ["relevant", "topic", "tags"]
          }
        ]
      }

      EXPLANATION REQUIREMENTS:
      - Minimum 100 words per explanation
      - Include step-by-step reasoning
      - Mathematical formulas in LaTeX format: $O(n \\log n)$, $$\\sum_{i=1}^{n} i = \\frac{n(n+1)}{2}$$
      - Code examples where relevant
      - Connection to broader concepts
      - Common mistakes to avoid

      ENSURE THE RESPONSE CONTAINS EXACTLY ${questionCount} QUESTIONS.`;

      const response = await InvokeLLM({
        prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            questions: {
              type: "array",
              minItems: questionCount,
              maxItems: questionCount,
              items: {
                type: "object",
                properties: {
                  question: { type: "string" },
                  options: { 
                    type: "array", 
                    items: { type: "string" },
                    minItems: 4,
                    maxItems: 4
                  },
                  correct_answer: { 
                    type: "number",
                    minimum: 0,
                    maximum: 3
                  },
                  explanation: { type: "string" },
                  source: { 
                    type: "object", 
                    properties: { 
                      title: { type: "string" }, 
                      url: { type: "string" } 
                    } 
                  },
                  difficulty_justification: { type: "string" },
                  learning_objective: { type: "string" },
                  tags: { type: "array", items: { type: "string" } }
                },
                required: ["question", "options", "correct_answer", "explanation", "source"]
              }
            }
          },
          required: ["questions"]
        }
      });

      if (!response.questions || response.questions.length !== questionCount) {
        throw new Error(`AI generated ${response.questions?.length || 0} questions but ${questionCount} were requested.`);
      }

      // Validate each question has exactly 4 options and a valid correct_answer
      const validQuestions = response.questions.filter(q => 
        q.options && 
        Array.isArray(q.options) && 
        q.options.length === 4 &&
        typeof q.correct_answer === 'number' &&
        q.correct_answer >= 0 &&
        q.correct_answer <= 3
      );

      if (validQuestions.length !== questionCount) {
        throw new Error(`Only ${validQuestions.length} out of ${questionCount} questions are properly formatted (4 options, valid correct answer index).`);
      }

      setQuestions(validQuestions);
      setUserAnswers(new Array(validQuestions.length).fill(null));
      setStep("quiz");
      setTimeLeft(timeLimit * 60);
    } catch (error) {
      console.error("Error generating quiz:", error);
      toast({
        title: "Quiz Generation Failed",
        description: error.message || "The AI could not generate questions. Please try again.",
        variant: "destructive",
      });
    }
    setIsLoading(false);
  };
  
  const handleAnswerSelect = (answerIndex) => {
    setUserAnswers(prev => {
      const newAnswers = [...prev];
      newAnswers[currentQuestion] = answerIndex;
      return newAnswers;
    });
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      handleQuizComplete();
    }
  };

  const resetQuiz = () => {
    const guestQuizzes = parseInt(localStorage.getItem('guestQuizCount') || '0');
    if (isGuest && guestQuizzes >= GUEST_QUIZ_LIMIT) {
      setStep('guest_limit');
    } else {
      setStep("subject");
    }
    setSelectedSubject(null);
    setCurrentQuestion(0);
    setUserAnswers([]);
    setQuestions([]);
    setQuizResults(null);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleLogin = async () => {
    await User.login();
  };

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-950 p-4 md:p-8 text-gray-900 dark:text-white">
      <div className="max-w-4xl mx-auto">
        <AnimatePresence mode="wait">
          {step === "subject" && (
            <motion.div
              key="subject"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <div className="text-center mb-8">
                <h1 className="text-3xl md:text-4xl font-bold mb-4">
                  Choose Your Subject 📚
                </h1>
                <p className="text-gray-500 dark:text-gray-400 text-lg">Select a subject to start your learning journey</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Object.entries(subjects).map(([key, subject]) => (
                  <motion.div
                    key={key}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Card
                      className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800 cursor-pointer hover:border-purple-500 transition-all duration-300"
                      onClick={() => { setSelectedSubject(key); setStep("config"); }}
                    >
                      <CardContent className="p-6 text-center">
                        <div className={`w-16 h-16 mx-auto mb-4 bg-gradient-to-r ${subject.color} rounded-xl flex items-center justify-center text-2xl`}>
                          {subject.icon}
                        </div>
                        <h3 className="font-bold text-lg mb-2">{subject.name}</h3>
                        <p className="text-gray-500 dark:text-gray-400 text-sm">Click to start quiz</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {step === "config" && (
            <motion.div
              key="config"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Card className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-6 h-6 text-purple-500 dark:text-purple-400" />
                    Configure Your Quiz
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-8">
                  <div>
                    <label className="font-medium mb-3 block">Difficulty Level</label>
                    <div className="grid grid-cols-3 gap-3">
                      {difficulties.map(diff => (
                        <Button
                          key={diff.value}
                          variant={difficulty === diff.value ? "default" : "outline"}
                          className={`${difficulty === diff.value ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' : 'border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-800'}`}
                          onClick={() => setDifficulty(diff.value)}
                        >
                          <span className={`${diff.color}`}>{diff.label}</span>
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="font-medium mb-3 block">Number of Questions: <span className="text-purple-500 font-bold">{questionCount}</span></label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {[5, 10, 15, 20].map(count => (
                        <Button
                          key={count}
                          variant={questionCount === count ? "default" : "outline"}
                           className={`${questionCount === count ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' : 'border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-800'}`}
                          onClick={() => setQuestionCount(count)}
                        >
                          {count} Questions
                        </Button>
                      ))}
                    </div>
                  </div>

                   <div>
                    <label className="font-medium mb-3 block">Time Limit: <span className="text-purple-500 font-bold">{timeLimit} mins</span></label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {[10, 20, 30, 60].map(time => (
                        <Button
                          key={time}
                          variant={timeLimit === time ? "default" : "outline"}
                           className={`${timeLimit === time ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' : 'border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-800'}`}
                          onClick={() => setTimeLimit(time)}
                        >
                          {time} mins
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
                    <Button
                      variant="outline"
                      onClick={() => setStep("subject")}
                      className="border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-800"
                    >
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Back
                    </Button>
                    <Button
                      onClick={generateQuiz}
                      disabled={isLoading}
                      className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
                    >
                      {isLoading ? (
                        <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Generating Quiz...</>
                      ) : (
                        <><Brain className="w-4 h-4 mr-2" /> Generate Quiz</>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {step === "guest_limit" && (
             <motion.div
              key="guest_limit"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
            >
              <Card className="w-full max-w-lg mx-auto bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800 text-center">
                <CardHeader>
                  <AlertTriangle className="mx-auto h-12 w-12 text-yellow-500" />
                  <CardTitle className="mt-4 text-2xl font-bold">Guest Limit Reached</CardTitle>
                  <p className="mt-2 text-gray-500 dark:text-gray-400">
                    You have completed the maximum number of quizzes allowed for guest users.
                  </p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 dark:text-gray-300">Please sign up or log in to continue taking quizzes, save your progress, and unlock all features.</p>
                  <Button
                    onClick={handleLogin}
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
                  >
                    <LogIn className="w-4 h-4 mr-2" />
                    Sign Up or Log In
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {step === "quiz" && questions.length > 0 && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              {/* Quiz Header */}
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
                <div>
                  <h1 className="text-2xl font-bold">{subjects[selectedSubject].name}</h1>
                  <p className="text-gray-500 dark:text-gray-400">Question {currentQuestion + 1} of {questions.length}</p>
                </div>
                <div className="flex items-center gap-4">
                  <Badge className={`font-mono text-base ${timeLeft <= 60 ? 'bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300' : 'bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300'}`}>
                    <Clock className="w-4 h-4 mr-2" />
                    {formatTime(timeLeft)}
                  </Badge>
                  <Progress value={((currentQuestion + 1) / questions.length) * 100} className="w-32" />
                </div>
              </div>

              <Card className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
                <CardContent className="p-8">
                  <div className="mb-6">
                    <h2 className="text-xl font-semibold mb-4">
                      {questions[currentQuestion]?.question}
                    </h2>
                    {questions[currentQuestion]?.source?.url && (
                       <a href={questions[currentQuestion].source.url} target="_blank" rel="noopener noreferrer" className="text-xs text-gray-400 hover:text-purple-500 transition-colors">
                         Source: {questions[currentQuestion].source.title || 'Reference'}
                       </a>
                    )}
                  </div>

                  <div className="space-y-3 mb-8">
                    {questions[currentQuestion]?.options.map((option, index) => (
                      <motion.div
                        key={index}
                        whileHover={{ x: 5 }}
                      >
                        <Button
                          variant="outline"
                          className={`w-full text-left p-4 h-auto justify-start border-2 transition-all duration-200 text-base
                            ${ userAnswers[currentQuestion] === index 
                              ? 'bg-purple-100 dark:bg-purple-900/50 border-purple-500 text-purple-700 dark:text-purple-300' 
                              : 'border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800/50'
                            }`}
                          onClick={() => handleAnswerSelect(index)}
                        >
                          <span className="font-medium mr-3">{String.fromCharCode(65 + index)}.</span>
                          {option}
                        </Button>
                      </motion.div>
                    ))}
                  </div>

                  <div className="flex justify-between items-center border-t border-gray-200 dark:border-gray-800 pt-6">
                    <Button
                      variant="outline"
                      onClick={() => setCurrentQuestion(prev => Math.max(0, prev - 1))}
                      disabled={currentQuestion === 0}
                      className="border-gray-300 dark:border-gray-600"
                    >
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Previous
                    </Button>
                    <p className="text-sm text-gray-500">{currentQuestion + 1} / {questions.length}</p>
                    <Button
                      onClick={handleNext}
                      disabled={userAnswers[currentQuestion] === null}
                      className="bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
                    >
                      {currentQuestion === questions.length - 1 ? "Complete Quiz" : "Next"}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {step === "results" && quizResults && (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <Card className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
                <CardHeader className="text-center">
                  <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                    <Trophy className="w-10 h-10 text-white" />
                  </div>
                  <CardTitle className="text-2xl">Quiz Complete!</CardTitle>
                  <p className="text-gray-500 dark:text-gray-400">Here's how you performed</p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center">
                    <div className="text-4xl font-bold mb-2">
                      {quizResults.score.toFixed(1)}%
                    </div>
                    <p className="text-gray-500 dark:text-gray-400">
                      {quizResults.correctAnswers} out of {quizResults.total} correct
                    </p>
                  </div>
                  
                  {quizResults.feedback && (
                    <div className="bg-gray-100 dark:bg-gray-800/50 rounded-xl p-4 border border-gray-200 dark:border-gray-700/50">
                      <h3 className="font-semibold mb-2 flex items-center gap-2">
                        <Brain className="w-5 h-5 text-purple-500 dark:text-purple-400" />
                        AI Feedback
                      </h3>
                      <p className="text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-wrap">{quizResults.feedback}</p>
                    </div>
                  )}

                  {quizResults.weakTopics && quizResults.weakTopics.length > 0 && (
                    <div className="bg-red-50 dark:bg-red-900/20 rounded-xl p-4 border border-red-200 dark:border-red-800/50">
                      <h3 className="font-semibold mb-3 text-red-800 dark:text-red-300">Areas to Focus On</h3>
                      <div className="flex flex-wrap gap-2">
                        {quizResults.weakTopics.map((topic, index) => (
                          <Badge key={index} className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">
                            {topic}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
                    <Button 
                      onClick={resetQuiz}
                      className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
                    >
                      Take Another Quiz
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => window.location.href = createPageUrl("dashboard")}
                      className="flex-1 border-gray-300 dark:border-gray-600"
                    >
                      Back to Dashboard
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Enhanced Detailed Solutions */}
              <Card className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-blue-500 dark:text-blue-400" />
                    Advanced Solutions & Analysis
                  </CardTitle>
                  <p className="text-gray-500 dark:text-gray-400">Comprehensive explanations with learning objectives</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-8">
                    {questions.map((question, index) => {
                      const userAnswer = userAnswers[index];
                      const isCorrect = userAnswer === question.correct_answer;

                      return (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6 border-l-4"
                          style={{ borderColor: isCorrect ? '#22c55e' : '#ef4444' }}
                        >
                          <div className="flex items-start gap-4 mb-6">
                            <div className="flex-1">
                              <h3 className="font-medium mb-3 leading-relaxed text-lg">
                                <span className="font-bold mr-3 text-purple-600 dark:text-purple-400">Q{index + 1}.</span>
                                {question.question}
                              </h3>
                              
                              {/* Learning Objective */}
                              {question.learning_objective && (
                                <div className="mb-3 p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800/50">
                                  <div className="text-xs font-medium text-blue-800 dark:text-blue-300 mb-1">LEARNING OBJECTIVE</div>
                                  <div className="text-sm text-blue-700 dark:text-blue-200">{question.learning_objective}</div>
                                </div>
                              )}

                              {/* Tags */}
                              {question.tags && question.tags.length > 0 && (
                                <div className="flex flex-wrap gap-1 mb-3">
                                  {question.tags.map((tag, tagIndex) => (
                                    <Badge key={tagIndex} variant="outline" className="text-xs">
                                      {tag}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                              
                              {question.source?.url && (
                                <a href={question.source.url} target="_blank" rel="noopener noreferrer" className="text-xs text-gray-400 hover:text-purple-500 transition-colors">
                                  📚 Source: {question.source.title || 'Reference'}
                                </a>
                              )
                              }
                            </div>
                            <div className={`flex items-center gap-2 font-medium ${
                                isCorrect ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                              }`}>
                              {isCorrect ? <CheckCircle className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
                              <span className="font-bold">{isCorrect ? 'CORRECT' : 'INCORRECT'}</span>
                            </div>
                          </div>

                          <div className="space-y-3 mb-6">
                            {question.options.map((option, optionIndex) => {
                              const isUserChoice = userAnswer === optionIndex;
                              const isCorrectChoice = question.correct_answer === optionIndex;
                              let variant = 'outline';
                              if (isCorrectChoice) variant = 'correct';
                              else if (isUserChoice && !isCorrectChoice) variant = 'incorrect';

                              return (
                                <div
                                  key={optionIndex}
                                  className={`p-4 rounded-lg border-2 flex items-center gap-4
                                    ${variant === 'correct' ? 'bg-green-50 dark:bg-green-900/30 border-green-500 text-green-800 dark:text-green-300' : ''}
                                    ${variant === 'incorrect' ? 'bg-red-50 dark:bg-red-900/30 border-red-500 text-red-800 dark:text-red-300' : ''}
                                    ${variant === 'outline' ? 'bg-gray-100 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600/50 text-gray-700 dark:text-gray-300' : ''}
                                  `}
                                >
                                  <span className="font-bold text-lg">{String.fromCharCode(65 + optionIndex)}.</span>
                                  <span className="flex-1">{option}</span>
                                  <div className="flex items-center gap-2">
                                    {isCorrectChoice && <CheckCircle className="w-4 h-4 text-green-600" />}
                                    {isUserChoice && (<Badge variant="secondary" className="text-xs">Your Choice</Badge>)}
                                  </div>
                                </div>
                              );
                            })}
                          </div>

                          {question.explanation && (
                            <div className="bg-gradient-to-r from-gray-100 to-gray-50 dark:from-gray-700/50 dark:to-gray-800/50 rounded-lg p-6 border border-gray-200 dark:border-gray-700/50">
                              <h4 className="font-bold text-lg mb-4 flex items-center gap-2 text-purple-600 dark:text-purple-400">
                                <Lightbulb className="w-5 h-5 text-yellow-500" />
                                Comprehensive Explanation
                              </h4>
                              <div className="text-gray-700 dark:text-gray-300 leading-relaxed whitespace-pre-wrap">
                                {question.explanation}
                              </div>
                              
                              {/* Difficulty Justification */}
                              {question.difficulty_justification && (
                                <div className="mt-4 p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800/50">
                                  <div className="text-xs font-medium text-purple-800 dark:text-purple-300 mb-1">DIFFICULTY ANALYSIS</div>
                                  <div className="text-sm text-purple-700 dark:text-purple-200">{question.difficulty_justification}</div>
                                </div>
                              )}
                            </div>
                          )}
                        </motion.div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
