// Real AI integration using Google Gemini API
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

export async function generateQuestionsWithGemini({ subject, difficulty, count, userProgress = null }) {
  const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
  
  if (!apiKey) {
    console.warn('Gemini API key not found. Using fallback question generation.');
    return null;
  }

  const progressContext = userProgress ? 
    `User's weak areas: ${userProgress.weak_topics?.join(', ') || 'None identified yet'}. ` +
    `Current performance level: ${userProgress.average_score || 'Unknown'}.` : '';

  const prompt = `You are an expert computer science educator creating quiz questions for students.

SUBJECT: ${subject}
DIFFICULTY: ${difficulty}
COUNT: Exactly ${count} questions
${progressContext}

Create ${count} COMPLETELY UNIQUE, high-quality multiple-choice questions that:
1. Test practical understanding, not just memorization
2. Include real-world applications and problem-solving
3. Cover different aspects of the subject (theory, implementation, debugging, optimization)
4. Are appropriate for ${difficulty} level learners
5. Include detailed explanations with step-by-step reasoning
6. Reference legitimate educational sources when possible
7. ABSOLUTELY NO DUPLICATE OR SIMILAR QUESTIONS - each must be distinctly different
8. Cover diverse subtopics within ${subject} to ensure variety

For coding questions:
- Include actual code snippets
- Test understanding of output, debugging, optimization
- Cover edge cases and common mistakes

For theoretical questions:
- Focus on WHY concepts work, not just WHAT they are
- Include practical applications
- Test critical thinking

Return EXACTLY this JSON format (no markdown, just pure JSON):
{
  "questions": [
    {
      "question": "Detailed question with context and requirements",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correct_answer": 0,
      "explanation": "Comprehensive explanation with reasoning, examples, and key concepts",
      "source": {
        "title": "Authoritative textbook or course name",
        "url": "https://legitimate-educational-resource.com"
      },
      "difficulty_justification": "Why this fits ${difficulty} level",
      "learning_objective": "What specific skill this tests",
      "tags": ["relevant", "topic", "tags"]
    }
  ]
}

CRITICAL UNIQUENESS REQUIREMENTS:
- Each question must be completely different from all others
- No two questions should test the same specific concept or code snippet
- Vary the question types: theoretical, practical, code analysis, debugging, algorithm design
- Use different programming constructs, algorithms, and examples
- If generating multiple algorithm questions, use different algorithms for each
- Ensure diverse subtopic coverage within ${subjects[selectedSubject].name}

Ensure questions are diverse, educational, and properly formatted. Return only the JSON object.`;

  try {
    const response = await fetch(`${GEMINI_API_URL}?key=${apiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: prompt
          }]
        }],
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 4000
        }
      })
    });

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
      throw new Error('Invalid response format from Gemini API');
    }

    const content = data.candidates[0].content.parts[0].text;
    
    // Clean the response - remove markdown formatting if present
    let cleanedContent = content.trim();
    if (cleanedContent.startsWith('```json')) {
      cleanedContent = cleanedContent.replace(/^```json\n?/, '').replace(/\n?```$/, '');
    } else if (cleanedContent.startsWith('```')) {
      cleanedContent = cleanedContent.replace(/^```\n?/, '').replace(/\n?```$/, '');
    }
    
    // Parse the JSON response
    const questionData = JSON.parse(cleanedContent);
    
    // Validate the response format
    if (!questionData.questions || !Array.isArray(questionData.questions)) {
      throw new Error('Invalid question format in Gemini response');
    }

    if (questionData.questions.length !== count) {
      console.warn(`Gemini generated ${questionData.questions.length} questions, expected ${count}`);
    }

    // Check for duplicate questions
    const uniqueQuestions = removeDuplicateQuestions(questionData.questions);
    if (uniqueQuestions.length < questionData.questions.length) {
      console.warn(`Removed ${questionData.questions.length - uniqueQuestions.length} duplicate questions`);
    }

    // If we lost too many questions due to duplicates, this is a problem
    if (uniqueQuestions.length < Math.max(1, count * 0.8)) {
      throw new Error(`Too many duplicate questions detected. Got ${uniqueQuestions.length} unique questions, expected ${count}`);
    }

    return uniqueQuestions;

  } catch (error) {
    console.error('Gemini question generation failed:', error);
    return null; // Fallback to local generation
  }
}

export async function generateChatResponseWithGemini({ message, context, subject = null }) {
  const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
  
  if (!apiKey) {
    console.warn('Gemini API key not found. Using fallback chat responses.');
    return null;
  }

  const systemContext = `You are an expert AI tutor specializing in computer science and programming.

Your teaching style:
- Clear, step-by-step explanations
- Use analogies and examples to clarify complex concepts
- Provide practical code examples when relevant
- Encourage critical thinking with follow-up questions
- Adapt complexity to the student's level

${subject ? `Current subject focus: ${subject}` : ''}

Guidelines:
- Be encouraging and supportive
- Explain not just WHAT but WHY and HOW
- Use proper formatting for code (use backticks)
- Include practical applications
- Suggest next steps for learning
- If you don't know something, be honest and suggest resources
- Keep responses educational and focused on learning`;

  // Build conversation context
  let conversationContext = systemContext + '\n\n';
  if (context && context.length > 0) {
    conversationContext += 'Previous conversation:\n';
    context.slice(-5).forEach(msg => {
      conversationContext += `${msg.role === 'user' ? 'Student' : 'Tutor'}: ${msg.message}\n`;
    });
    conversationContext += '\n';
  }
  conversationContext += `Student: ${message}\nTutor: `;

  try {
    const response = await fetch(`${GEMINI_API_URL}?key=${apiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: conversationContext
          }]
        }],
        generationConfig: {
          temperature: 0.8,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 1500
        }
      })
    });

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
      throw new Error('Invalid response format from Gemini API');
    }

    const content = data.candidates[0].content.parts[0].text;
    return content.trim();

  } catch (error) {
    console.error('Gemini chat response failed:', error);
    return null; // Fallback to local responses
  }
}

// Helper to check if Gemini is configured
export function isGeminiConfigured() {
  return !!import.meta.env.VITE_GEMINI_API_KEY;
}

// Helper function to remove duplicate questions
function removeDuplicateQuestions(questions) {
  const unique = [];
  const seenQuestions = new Set();
  const seenConcepts = new Set();
  
  for (const question of questions) {
    // Create a normalized version for comparison
    const normalizedQuestion = question.question
      .toLowerCase()
      .replace(/[^a-z0-9]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    
    // Check for exact or very similar questions
    if (seenQuestions.has(normalizedQuestion)) {
      console.log('Skipping duplicate question:', question.question.substring(0, 50) + '...');
      continue;
    }
    
    // Check for similarity by extracting key concepts
    const concepts = extractKeyConcepts(normalizedQuestion);
    const conceptKey = concepts.sort().join('|');
    
    // Allow some concept overlap but not complete overlap
    if (conceptKey && seenConcepts.has(conceptKey)) {
      console.log('Skipping similar concept question:', question.question.substring(0, 50) + '...');
      continue;
    }
    
    seenQuestions.add(normalizedQuestion);
    if (conceptKey) seenConcepts.add(conceptKey);
    unique.push(question);
  }
  
  return unique;
}

// Extract key concepts from a question for similarity detection
function extractKeyConcepts(normalizedQuestion) {
  // Common programming/CS concepts to look for
  const concepts = [
    'time complexity', 'space complexity', 'big o', 'algorithm', 'data structure',
    'array', 'linked list', 'stack', 'queue', 'tree', 'graph', 'hash table',
    'sorting', 'searching', 'recursion', 'dynamic programming', 'greedy',
    'binary search', 'quicksort', 'mergesort', 'heap', 'bst',
    'inheritance', 'polymorphism', 'encapsulation', 'abstraction',
    'constructor', 'destructor', 'virtual function', 'overloading', 'overriding',
    'malloc', 'pointer', 'reference', 'memory', 'garbage collection',
    'exception', 'thread', 'synchronization', 'deadlock',
    'database', 'sql', 'transaction', 'normalization',
    'testing', 'debugging', 'version control', 'design pattern'
  ];
  
  const foundConcepts = [];
  for (const concept of concepts) {
    if (normalizedQuestion.includes(concept)) {
      foundConcepts.push(concept);
    }
  }
  
  return foundConcepts;
}
