import * as React from "react"

// Simple toast implementation for demo purposes
export function useToast() {
  const toast = ({ title, description, variant = "default" }) => {
    // Mock implementation with better user feedback
    console.log(`Toast: ${title}`, { description, variant });
    
    // Create a temporary visual notification
    const notification = document.createElement('div');
    notification.className = `
      fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm
      ${variant === 'destructive' ? 'bg-red-900 border border-red-600 text-red-100' : 
        variant === 'success' ? 'bg-green-900 border border-green-600 text-green-100' :
        'bg-gray-900 border border-gray-600 text-white'}
    `;
    notification.innerHTML = `
      <div class="font-semibold text-sm">${title}</div>
      ${description ? `<div class="text-xs mt-1 opacity-90">${description}</div>` : ''}
    `;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 3000);
  };

  return { toast };
}

export { useToast as default };
