import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import Layout from '../Layout.jsx'
import Dashboard from '../Pages/Dashboard.jsx'
import Quiz from '../Pages/Quiz.jsx'
import History from '../Pages/History.jsx'
import Tutor from '../Pages/Tutor.jsx'
import Account from '../Pages/Account.jsx'
import Report from '../Pages/Report.jsx'

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Layout><Dashboard /></Layout>} />
        <Route path="/quiz" element={<Layout><Quiz /></Layout>} />
        <Route path="/history" element={<Layout><History /></Layout>} />
        <Route path="/tutor" element={<Layout><Tutor /></Layout>} />
        <Route path="/account" element={<Layout><Account /></Layout>} />
        <Route path="/report" element={<Layout><Report /></Layout>} />
      </Routes>
    </Router>
  )
}

export default App
