// Real AI integration using OpenAI API
// To use this, set OPENAI_API_KEY environment variable or add it to your .env file

const OPENAI_API_URL = 'https://api.openai.com/v1/chat/completions';

export async function generateQuestionsWithOpenAI({ subject, difficulty, count, userProgress = null }) {
  // Check for API key in browser environment
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  
  if (!apiKey) {
    console.warn('OpenAI API key not found. Using fallback question generation.');
    return null;
  }

  const progressContext = userProgress ? 
    `User's weak areas: ${userProgress.weak_topics?.join(', ') || 'None identified yet'}. ` +
    `Current performance level: ${userProgress.average_score || 'Unknown'}.` : '';

  const prompt = `You are an expert educator creating quiz questions for computer science students.

SUBJECT: ${subject}
DIFFICULTY: ${difficulty}
COUNT: Exactly ${count} questions
${progressContext}

Create ${count} unique, high-quality multiple-choice questions that:
1. Test practical understanding, not just memorization
2. Include real-world applications and problem-solving
3. Cover different aspects of the subject (theory, implementation, debugging, optimization)
4. Are appropriate for ${difficulty} level learners
5. Include detailed explanations with step-by-step reasoning
6. Reference legitimate educational sources when possible

For coding questions:
- Include actual code snippets
- Test understanding of output, debugging, optimization
- Cover edge cases and common mistakes

For theoretical questions:
- Focus on WHY concepts work, not just WHAT they are
- Include practical applications
- Test critical thinking

Return EXACTLY this JSON format:
{
  "questions": [
    {
      "question": "Detailed question with context and requirements",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correct_answer": 0,
      "explanation": "Comprehensive explanation with reasoning, examples, and key concepts",
      "source": {
        "title": "Authoritative textbook or course name",
        "url": "https://legitimate-educational-resource.com"
      },
      "difficulty_justification": "Why this fits ${difficulty} level",
      "learning_objective": "What specific skill this tests",
      "tags": ["relevant", "topic", "tags"]
    }
  ]
}

Ensure questions are diverse, educational, and properly formatted.`;

  try {
    const response = await fetch(OPENAI_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: 'You are an expert computer science educator who creates high-quality, educational quiz questions. Always return valid JSON in the exact format requested.'
          },
          {
            role: 'user', 
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 4000
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content;
    
    // Parse the JSON response
    const questionData = JSON.parse(content);
    
    // Validate the response format
    if (!questionData.questions || questionData.questions.length !== count) {
      throw new Error(`Expected ${count} questions, got ${questionData.questions?.length || 0}`);
    }

    return questionData.questions;

  } catch (error) {
    console.error('OpenAI question generation failed:', error);
    return null; // Fallback to local generation
  }
}

export async function generateChatResponseWithOpenAI({ message, context, subject = null }) {
  // Check for API key in browser environment
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  
  if (!apiKey) {
    console.warn('OpenAI API key not found. Using fallback chat responses.');
    return null;
  }

  const systemPrompt = `You are an expert AI tutor specializing in computer science and programming. 

Your teaching style:
- Clear, step-by-step explanations
- Use analogies and examples to clarify complex concepts
- Provide practical code examples when relevant
- Encourage critical thinking with follow-up questions
- Adapt complexity to the student's level

${subject ? `Current subject focus: ${subject}` : ''}

Guidelines:
- Be encouraging and supportive
- Explain not just WHAT but WHY and HOW
- Use proper formatting for code (markdown)
- Include practical applications
- Suggest next steps for learning
- If you don't know something, be honest and suggest resources`;

  try {
    const response = await fetch(OPENAI_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: systemPrompt },
          ...context.slice(-10), // Last 10 messages for context
          { role: 'user', content: message }
        ],
        temperature: 0.7,
        max_tokens: 1000
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;

  } catch (error) {
    console.error('OpenAI chat response failed:', error);
    return null; // Fallback to local responses
  }
}

// Helper to check if OpenAI is configured
export function isOpenAIConfigured() {
  return !!import.meta.env.VITE_OPENAI_API_KEY;
}
